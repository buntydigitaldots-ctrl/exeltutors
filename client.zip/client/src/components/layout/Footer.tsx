import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Linkedin, Instagram, Facebook, Twitter } from "lucide-react";

const subjects = [
  "Mathematics",
  "Science",
  "English",
  "Hindi",
  "Punjabi",
  "Music Instruments",
];

export const Footer = (): JSX.Element => {
  return (
    <footer className="w-full bg-[#070709]">
      <div className="w-full px-4 md:px-[100px] py-8 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12 lg:gap-24">
          <div className="flex flex-col">
            <div className="font-['Inter'] font-bold text-2xl md:text-[40px] tracking-[0] leading-normal whitespace-nowrap mb-8 md:mb-16">
              <span className="text-[#22a3d2]">Tutor</span>
              <span className="text-[#ff9e10]">Exel</span>
            </div>

            <p className="font-['Nunito_Sans'] font-normal text-white text-sm md:text-xl tracking-[0] leading-[30px] mb-8 md:mb-12">
              <span className="leading-[30px]">At </span>
              <span className="font-bold leading-[30px]">TutorExel,</span>
              <span className="leading-[30px]">
                {" "}
                we understand student struggles and parent concerns. Our
                personalized online tutoring builds confidence, improves
                performance, and helps students reach their academic goals—every
                step of the way.
              </span>
            </p>

            <div className="flex gap-4">
              <Linkedin className="w-6 h-6 md:w-8 md:h-8 text-[#22a3d2] cursor-pointer hover:opacity-80 transition-opacity" />
              <Instagram className="w-6 h-6 md:w-8 md:h-8 text-[#ff9e10] cursor-pointer hover:opacity-80 transition-opacity" />
              <Facebook className="w-6 h-6 md:w-8 md:h-8 text-[#22a3d2] cursor-pointer hover:opacity-80 transition-opacity" />
              <Twitter className="w-6 h-6 md:w-8 md:h-8 text-[#22a3d2] cursor-pointer hover:opacity-80 transition-opacity" />
            </div>
          </div>

          <div className="flex flex-col">
            <h3 className="font-['Nunito_Sans'] font-bold text-white text-xl md:text-3xl tracking-[0] leading-normal mb-8 md:mb-16">
              Subjects
            </h3>
            <ul className="font-['Nunito_Sans'] font-normal text-white text-sm md:text-xl tracking-[0] leading-10">
              {subjects.map((subject, index) => (
                <li key={index} className="cursor-pointer hover:text-[#22a3d2]">{subject}</li>
              ))}
            </ul>
          </div>

          <div className="flex flex-col">
            <h3 className="font-['Nunito_Sans'] font-bold text-white text-xl md:text-3xl tracking-[0] leading-normal mb-8 md:mb-16">
              Subscribe
            </h3>
            <div className="flex flex-col gap-4 md:gap-8">
              <Input
                type="email"
                placeholder="Enter your Email"
                className="w-full md:w-[343px] h-12 md:h-[60px] bg-white rounded-full px-6 md:px-9 font-['Nunito_Sans'] font-normal text-[#070709] text-sm md:text-lg tracking-[0] leading-[19.8px] border-0"
              />
              <Button className="w-full md:w-[248px] h-12 md:h-[60px] bg-[#ff9e10] rounded-full font-['Nunito_Sans'] font-bold text-white text-sm md:text-lg tracking-[1.80px] leading-[19.8px] hover:bg-[#ff9e10]/90 uppercase">
                Subscribe now
              </Button>
            </div>
          </div>

          <div className="flex flex-col">
            <h3 className="font-['Nunito_Sans'] font-bold text-white text-xl md:text-3xl tracking-[0] leading-normal mb-6 md:mb-10">
              Contact
            </h3>
            <div className="flex gap-3 md:gap-5 items-start">
              <img
                className="mt-1 w-5 md:w-[27px] h-5 md:h-[25px]"
                alt="Email"
                src="/figmaAssets/vector-16.svg"
              />
              <a
                className="font-['Nunito_Sans'] font-bold text-white text-sm md:text-[25px] tracking-[0] leading-normal hover:text-[#22a3d2] break-all"
                href="mailto:info@tutorexel.com"
                rel="noopener noreferrer"
                target="_blank"
              >
                info@tutorexel.com
              </a>
            </div>
          </div>
        </div>
      </div>

      <div className="w-full h-auto md:h-20 bg-[#141414] flex items-center px-4 md:px-[100px] py-4 md:py-0">
        <p className="font-['Nunito_Sans'] font-bold text-xs md:text-xl tracking-[0] leading-normal">
          <span className="text-white">Copyright © 2025 </span>
          <span className="text-[#22a3d2]">Tutor</span>
          <span className="text-[#ff9e10]">Exel</span>
          <span className="text-white">
            &nbsp;&nbsp;|&nbsp;&nbsp;All Rights Reserved
          </span>
        </p>
      </div>
    </footer>
  );
};
