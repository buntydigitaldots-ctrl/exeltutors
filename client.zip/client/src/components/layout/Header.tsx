import { SearchIcon, Linkedin, Instagram, Facebook, Twitter, ChevronDown } from "lucide-react";
import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";

const navigationItems = [
  { label: "Home", path: "/" },
  { label: "About Us", path: "/about" },
  { label: "Pricing", path: "/pricing" },
  { label: "Contact Us", path: "/contact" },
  { label: "FAQs", path: "/faqs" },
];

const examPrepItems = [
  { label: "ICAS", path: "/icas", group: "ICAS" },
  { label: "ICAS Primary", path: "/icas/primary", group: "ICAS" },
  { label: "ICAS Secondary", path: "/icas/secondary", group: "ICAS" },
  { label: "NAPLAN", path: "/naplan", group: "NAPLAN" },
  { label: "NAPLAN Primary", path: "/naplan/primary", group: "NAPLAN" },
  { label: "NAPLAN Secondary", path: "/naplan/secondary", group: "NAPLAN" },
  { label: "Piano Classes", path: "/piano", group: "Co-Curricular" },
];

interface HeaderProps {
  showFreeTrial?: boolean;
}

export const Header = ({ showFreeTrial = false }: HeaderProps): JSX.Element => {
  const [location] = useLocation();
  const [isExamPrepOpen, setIsExamPrepOpen] = useState(false);

  return (
    <header className="w-full">
      <div className="w-full h-10 bg-[#22a3d2] flex items-center justify-end">
        <div className="flex items-center">
          <div className="flex items-center gap-2 bg-[#ff9e10] h-10 px-5">
            <img
              className="w-5 h-5 object-cover"
              alt="UK Flag"
              src="/figmaAssets/united-kingdom-1.png"
            />
            <span className="text-white text-xs font-bold font-['Nunito_Sans']">
              English
            </span>
            <img
              className="w-1.5 h-1"
              alt="Dropdown"
              src="/figmaAssets/polygon-1.svg"
            />
          </div>
          
          <div className="flex items-center h-10 px-3 bg-[#ff9e10] gap-2">
            <Linkedin className="w-4 h-4 text-white cursor-pointer hover:opacity-80" />
            <Instagram className="w-4 h-4 text-white cursor-pointer hover:opacity-80" />
            <Facebook className="w-4 h-4 text-white cursor-pointer hover:opacity-80" />
            <Twitter className="w-4 h-4 text-white cursor-pointer hover:opacity-80" />
          </div>
        </div>
      </div>

      <nav className="w-full h-auto md:h-[120px] flex flex-col md:flex-row items-center justify-between px-4 md:px-[100px] py-4 md:py-0 bg-white gap-4 md:gap-0">
        <Link href="/">
          <img
            className="h-[24px] md:h-[30px] w-auto cursor-pointer"
            alt="TutorExel"
            src="/figmaAssets/tutorexel.png"
          />
        </Link>

        <div className="hidden md:flex items-center">
          {navigationItems.map((item, index) => {
            const isActive = location === item.path;
            return (
              <Link key={index} href={item.path}>
                <button
                  className={`h-[120px] px-3 lg:px-5 font-['Nunito_Sans'] font-bold text-sm lg:text-xl transition-colors ${
                    isActive
                      ? "bg-[#ff9e10] text-white"
                      : "bg-transparent text-[#070709] hover:text-[#22a3d2]"
                  }`}
                >
                  {item.label}
                </button>
              </Link>
            );
          })}

          {/* Exam Prep Dropdown */}
          <div className="relative">
            <button
              onClick={() => setIsExamPrepOpen(!isExamPrepOpen)}
              className={`h-[120px] px-3 lg:px-5 font-['Nunito_Sans'] font-bold text-sm lg:text-xl transition-colors flex items-center gap-1 ${
                isExamPrepOpen
                  ? "bg-[#ff9e10] text-white"
                  : "bg-transparent text-[#070709] hover:text-[#22a3d2]"
              }`}
            >
              Exam Prep
              <ChevronDown className="w-4 h-4" />
            </button>

            {/* Dropdown Menu */}
            {isExamPrepOpen && (
              <div className="absolute top-[120px] left-0 bg-white border-l-4 border-[#ff9e10] shadow-lg z-50 min-w-[220px]">
                {/* ICAS Group */}
                <div className="border-b border-gray-200">
                  <p className="px-4 py-2 font-['Nunito_Sans'] font-bold text-xs text-[#22a3d2] bg-gray-50">
                    ICAS
                  </p>
                  <Link href="/icas">
                    <button className="w-full text-left px-4 py-2 font-['Nunito_Sans'] text-sm text-[#070709] hover:bg-[#fff9e6]">
                      ICAS Main
                    </button>
                  </Link>
                  <Link href="/icas/primary">
                    <button className="w-full text-left px-4 py-2 font-['Nunito_Sans'] text-sm text-[#070709] hover:bg-[#fff9e6]">
                      Primary (Years 2-6)
                    </button>
                  </Link>
                  <Link href="/icas/secondary">
                    <button className="w-full text-left px-4 py-2 font-['Nunito_Sans'] text-sm text-[#070709] hover:bg-[#fff9e6]">
                      Secondary (Years 7-10)
                    </button>
                  </Link>
                </div>

                {/* NAPLAN Group */}
                <div className="border-b border-gray-200">
                  <p className="px-4 py-2 font-['Nunito_Sans'] font-bold text-xs text-[#22a3d2] bg-gray-50">
                    NAPLAN
                  </p>
                  <Link href="/naplan">
                    <button className="w-full text-left px-4 py-2 font-['Nunito_Sans'] text-sm text-[#070709] hover:bg-[#fff9e6]">
                      NAPLAN Main
                    </button>
                  </Link>
                  <Link href="/naplan/primary">
                    <button className="w-full text-left px-4 py-2 font-['Nunito_Sans'] text-sm text-[#070709] hover:bg-[#fff9e6]">
                      Primary (Years 3 & 5)
                    </button>
                  </Link>
                  <Link href="/naplan/secondary">
                    <button className="w-full text-left px-4 py-2 font-['Nunito_Sans'] text-sm text-[#070709] hover:bg-[#fff9e6]">
                      Secondary (Years 7 & 9)
                    </button>
                  </Link>
                </div>

                {/* Co-Curricular Group */}
                <div>
                  <p className="px-4 py-2 font-['Nunito_Sans'] font-bold text-xs text-[#22a3d2] bg-gray-50">
                    Co-Curricular
                  </p>
                  <Link href="/piano">
                    <button className="w-full text-left px-4 py-2 font-['Nunito_Sans'] text-sm text-[#070709] hover:bg-[#fff9e6]">
                      Piano Classes
                    </button>
                  </Link>
                </div>
              </div>
            )}
          </div>

          {/* Blogs after Exam Prep */}
          <Link href="/blogs">
            <button
              className={`h-[120px] px-3 lg:px-5 font-['Nunito_Sans'] font-bold text-sm lg:text-xl transition-colors ${
                location === "/blogs"
                  ? "bg-[#ff9e10] text-white"
                  : "bg-transparent text-[#070709] hover:text-[#22a3d2]"
              }`}
            >
              Blogs
            </button>
          </Link>
        </div>

        <div className="flex items-center gap-3 md:gap-6">
          <Button variant="ghost" size="icon" className="w-8 md:w-10 h-8 md:h-10">
            <SearchIcon className="w-5 md:w-6 h-5 md:h-6 text-[#070709]" />
          </Button>

          {showFreeTrial ? (
            <Button className="h-10 md:h-[60px] px-4 md:px-10 bg-[#22a3d2] rounded-full font-['Nunito_Sans'] font-bold text-white text-sm md:text-xl hover:bg-[#1a8ab0]">
              Free Trial
            </Button>
          ) : (
            <Button className="h-10 md:h-[60px] px-4 md:px-10 bg-[#22a3d2] rounded-full font-['Nunito_Sans'] font-bold text-white text-sm md:text-xl hover:bg-[#1a8ab0]">
              Login
            </Button>
          )}
        </div>
      </nav>
    </header>
  );
};
