import React from "react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const ContactPage = (): JSX.Element => {
  return (
    <div className="bg-white w-full min-h-screen">
      <Header showFreeTrial />

      <div className="w-full px-4 md:px-[100px] py-8 md:py-16">
        <h1 className="font-['Nunito_Sans'] font-extrabold text-3xl md:text-4xl lg:text-[50px] text-[#070709] text-center mb-3 md:mb-4">
          Contact Us
        </h1>
        <p className="font-['Nunito_Sans'] text-sm md:text-base lg:text-xl text-[#070709] text-center mb-8 md:mb-16 max-w-2xl mx-auto">
          Have questions? We'd love to hear from you. Send us a message and we'll respond as soon as possible.
        </p>
        
        <div className="max-w-2xl mx-auto">
          <form className="space-y-4 md:space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
              <div>
                <label className="font-['Nunito_Sans'] font-bold text-sm md:text-base text-[#070709] block mb-2">First Name</label>
                <Input className="h-10 md:h-14 rounded-xl border-gray-200 text-sm md:text-base" placeholder="Enter your first name" />
              </div>
              <div>
                <label className="font-['Nunito_Sans'] font-bold text-sm md:text-base text-[#070709] block mb-2">Last Name</label>
                <Input className="h-10 md:h-14 rounded-xl border-gray-200 text-sm md:text-base" placeholder="Enter your last name" />
              </div>
            </div>
            
            <div>
              <label className="font-['Nunito_Sans'] font-bold text-sm md:text-base text-[#070709] block mb-2">Email</label>
              <Input type="email" className="h-10 md:h-14 rounded-xl border-gray-200 text-sm md:text-base" placeholder="Enter your email" />
            </div>
            
            <div>
              <label className="font-['Nunito_Sans'] font-bold text-sm md:text-base text-[#070709] block mb-2">Phone</label>
              <Input type="tel" className="h-10 md:h-14 rounded-xl border-gray-200 text-sm md:text-base" placeholder="Enter your phone number" />
            </div>
            
            <div>
              <label className="font-['Nunito_Sans'] font-bold text-sm md:text-base text-[#070709] block mb-2">Message</label>
              <textarea 
                className="w-full h-32 md:h-40 px-4 py-3 rounded-xl border border-gray-200 font-['Nunito_Sans'] text-sm md:text-base resize-none focus:outline-none focus:ring-2 focus:ring-[#22a3d2]" 
                placeholder="How can we help you?"
              />
            </div>
            
            <Button className="w-full h-10 md:h-14 bg-[#22a3d2] hover:bg-[#1a8ab0] rounded-full font-['Nunito_Sans'] font-bold text-sm md:text-xl text-white">
              Send Message
            </Button>
          </form>
          
          <div className="mt-8 md:mt-16 grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 text-center">
            <div>
              <h3 className="font-['Nunito_Sans'] font-bold text-base md:text-lg lg:text-xl text-[#22a3d2] mb-2">Email</h3>
              <p className="font-['Nunito_Sans'] text-xs md:text-sm lg:text-base text-[#070709]">info@tutorexel.com</p>
            </div>
            <div>
              <h3 className="font-['Nunito_Sans'] font-bold text-base md:text-lg lg:text-xl text-[#22a3d2] mb-2">Phone</h3>
              <p className="font-['Nunito_Sans'] text-xs md:text-sm lg:text-base text-[#070709]">+61 123 456 789</p>
            </div>
            <div>
              <h3 className="font-['Nunito_Sans'] font-bold text-base md:text-lg lg:text-xl text-[#22a3d2] mb-2">Hours</h3>
              <p className="font-['Nunito_Sans'] text-xs md:text-sm lg:text-base text-[#070709]">Mon-Fri: 9am-6pm</p>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};
