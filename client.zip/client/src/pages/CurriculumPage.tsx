import React, { useState } from "react";
import { Link, useParams } from "wouter";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { CTASection } from "./sections/CTASection";

const years = ["Year 2", "Year 3", "Year 4", "Year 5", "Year 6", "Year 7", "Year 8", "Year 9", "Year 10"];

const termColors = {
  "term1": { header: "#22a3d2", border: "#22a3d2", light: "#e8f4f8" },
  "term2": { header: "#ff9e10", border: "#ff9e10", light: "#fff5e8" },
  "term3": { header: "#1abc9c", border: "#1abc9c", light: "#e8f8f5" },
  "term4": { header: "#9b59b6", border: "#9b59b6", light: "#f4e8f8" }
};

const curriculumData = {
  "term1": {
    title: "TERM 1 - Foundations",
    topics: [
      { skill: 1, name: "Purpose & Main Idea", description: "Learn to identify why a text is written and find its main idea." },
      { skill: 2, name: "Order of Events", description: "Identify the correct sequence of events in informational texts." },
      { skill: 3, name: "Story Elements", description: "Recognise characters, setting, problem and solution in stories." },
      { skill: 4, name: "Facts vs Opinions", description: "Learn the difference between factual statements and opinions." },
      { skill: 5, name: "Sentence Types", description: "Understand the four types of sentences and how they are used." },
      { skill: 6, name: "Nouns", description: "Identify different types of nouns: common, proper and abstract." },
      { skill: 7, name: "Pronouns", description: "Learn to recognise personal pronouns that replace nouns." },
      { skill: 8, name: "Verbs & Helping Verbs", description: "Identify action verbs, main verbs and helping verbs." },
      { skill: 9, name: "Subjects & Predicates", description: "Identify the subject and predicate to understand sentence structure." },
      { skill: 10, name: "Listening for Key Points", description: "Practise listening carefully, responding and acknowledging others' ideas." },
    ]
  },
  "term2": {
    title: "TERM 2 — Vocabulary & Grammar Extension",
    topics: [
      { skill: 11, name: "Synonyms", description: "Learn words with similar meanings to improve vocabulary." },
      { skill: 12, name: "Antonyms", description: "Learn words with opposite meanings to expand vocabulary." },
      { skill: 13, name: "Similes & Metaphors", description: "Identify and understand similes and metaphors in texts." },
      { skill: 14, name: "Conjunctions", description: "Learn how conjunctions join words and ideas in sentences." },
      { skill: 15, name: "Adjectives", description: "Identify adjectives and understand how they describe nouns." },
      { skill: 16, name: "Adverbs", description: "Learn how adverbs show how, when, and where actions happen." },
      { skill: 17, name: "Effects of Figurative Devices", description: "Understand how similes and metaphors affect meaning and tone." },
      { skill: 18, name: "Prepositions & Phrases", description: "Identify prepositions and prepositional phrases in sentences." },
      { skill: 19, name: "Discussions & Opinions", description: "Practise sharing opinions, responding politely, and discussing ideas." },
      { skill: 20, name: "Paragraph Structure & Transitions", description: "Learn to organise paragraphs and use transitions effectively." },
    ]
  },
  "term3": {
    title: "TERM 3 — Literature & Interpretation",
    topics: [
      { skill: 21, name: "Understanding Characters", description: "Use characters' actions and dialogue to understand their traits." },
      { skill: 22, name: "Comparing Characters", description: "Compare similarities and differences between characters." },
      { skill: 23, name: "Setting & Plot Tension", description: "Understand how authors build tension through the setting and plot." },
      { skill: 24, name: "Point of View", description: "Identify first- and third-person narration in stories." },
      { skill: 25, name: "Drawing Inferences", description: "Use clues in the text to infer ideas and deeper meaning." },
      { skill: 26, name: "Myths & Folktales", description: "Explore themes found in myths, folktales and fables." },
      { skill: 27, name: "Reading Poetry", description: "Read poems and understand rhythm, imagery and wordplay." },
      { skill: 28, name: "Sensory Details", description: "Identify sensory words that create vivid descriptions." },
      { skill: 29, name: "Devices in Literature", description: "Examine the effect of figurative language in stories and poems." },
      { skill: 30, name: "Oral Responses to Literature", description: "Share opinions and explain ideas aloud about texts read." },
    ]
  },
  "term4": {
    title: "TERM 4 - Writing Mastery, Grammar, Editing & Presenting",
    topics: [
      { skill: 31, name: "Complex Sentences", description: "Learn how to build complex sentences using clauses." },
      { skill: 32, name: "Verb Tenses", description: "Identify and use different verb tenses in writing." },
      { skill: 33, name: "Progressive & Perfect Tenses", description: "Learn to use progressive and perfect verb tenses correctly." },
      { skill: 34, name: "Persuasive Writing", description: "Learn to express opinions and support them with reasons." },
      { skill: 35, name: "Informative Writing", description: "Organise ideas and facts to write clear informative texts." },
      { skill: 36, name: "Narrative Writing", description: "Create stories with characters, settings and organised events." },
      { skill: 37, name: "Sentence Editing", description: "Edit sentences for fragments, run-ons and correct structure." },
      { skill: 38, name: "Precision in Vocabulary", description: "Use stronger words, synonyms and antonyms to improve writing." },
      { skill: 39, name: "Oral & Multimodal Presentations", description: "Plan and deliver a clear, confident oral or visual presentation." },
      { skill: 40, name: "Final Review of Skills", description: "Apply reading and writing strategies across all text types." },
    ]
  }
};

export const CurriculumPage = (): JSX.Element => {
  const params = useParams();
  const yearParam = params.year || "year-3";
  const currentYear = yearParam.replace("-", " ").replace(/\b\w/g, l => l.toUpperCase());
  
  const [activeSubject, setActiveSubject] = useState<"maths" | "english">("maths");

  return (
    <div className="bg-white w-full min-h-screen">
      <Header showFreeTrial />

      <div className="w-full px-4 md:px-8 lg:px-12 py-6 md:py-8">
        {/* Year Navigation */}
        <div className="flex flex-wrap items-center gap-1 md:gap-2 text-sm md:text-base font-['Nunito_Sans'] mb-6 md:mb-8 overflow-x-auto">
          {years.map((year, index) => (
            <React.Fragment key={year}>
              <Link href={`/curriculum/${year.toLowerCase().replace(" ", "-")}`}>
                <span className={`cursor-pointer hover:text-[#22a3d2] whitespace-nowrap ${currentYear === year ? "font-bold text-[#22a3d2]" : "text-[#070709]"}`}>
                  {year}
                </span>
              </Link>
              {index < years.length - 1 && <span className="text-gray-300">/</span>}
            </React.Fragment>
          ))}
        </div>

        {/* Subject Tabs */}
        <div className="flex flex-col sm:flex-row gap-2 md:gap-3 mb-8 md:mb-10">
          <button
            onClick={() => setActiveSubject("maths")}
            className={`px-6 md:px-8 py-2 md:py-2.5 rounded-full font-['Nunito_Sans'] font-bold text-sm md:text-base transition-colors ${
              activeSubject === "maths"
                ? "bg-[#22a3d2] text-white"
                : "bg-[#f0f0f0] text-[#070709] hover:bg-[#e0e0e0]"
            }`}
          >
            Maths
          </button>
          <button
            onClick={() => setActiveSubject("english")}
            className={`px-6 md:px-8 py-2 md:py-2.5 rounded-full font-['Nunito_Sans'] font-bold text-sm md:text-base transition-colors ${
              activeSubject === "english"
                ? "bg-[#22a3d2] text-white"
                : "bg-[#f0f0f0] text-[#070709] hover:bg-[#e0e0e0]"
            }`}
          >
            English
          </button>
        </div>

        {/* Title Section */}
        <div className="mb-8 md:mb-10">
          <h1 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl lg:text-[36px] text-[#070709] mb-2">
            {currentYear}
          </h1>
          <h2 className="font-['Nunito_Sans'] font-bold text-lg md:text-xl text-[#070709] mb-3 md:mb-4">
            We've Got the Curriculum Covered
          </h2>
          <p className="font-['Nunito_Sans'] text-sm md:text-base text-[#070709] leading-relaxed max-w-4xl mb-3">
            At TutorExel, our {currentYear} {activeSubject === "maths" ? "Maths" : "English"} program builds a strong foundation in number skills, operations, early fractions, and patterns. Lessons are tailored to your child's pace and aligned with the Australian National Curriculum.
          </p>
          <p className="font-['Nunito_Sans'] text-sm md:text-base text-[#070709] leading-relaxed mb-4">
            Tutoring is delivered through 1-on-1 or group (4:1) online sessions, guided by expert tutors who focus on real progress.
          </p>
          <p className="font-['Nunito_Sans'] font-bold text-sm md:text-base text-[#ff9e10]">
            To Practice click on Topic Name
          </p>
        </div>

        {/* Terms */}
        {Object.entries(curriculumData).map(([termKey, term]) => {
          const colors = termColors[termKey as keyof typeof termColors];
          return (
            <div key={termKey} className="mb-8 md:mb-12">
              {/* Term Title with colored background */}
              <div
                className="px-4 md:px-6 py-3 md:py-4 rounded-t-2xl"
                style={{ backgroundColor: colors.header }}
              >
                <h3 className="font-['Nunito_Sans'] font-bold text-base md:text-lg text-white">
                  {term.title}
                </h3>
              </div>

              {/* Table */}
              <div
                className="overflow-x-auto rounded-b-2xl border-2"
                style={{ borderColor: colors.border }}
              >
                <table className="w-full">
                  {/* Table Header */}
                  <thead>
                    <tr style={{ backgroundColor: colors.light }}>
                      <th className="py-3 md:py-4 px-3 md:px-5 text-left font-['Nunito_Sans'] font-bold text-xs md:text-sm lg:text-base w-12 md:w-16">
                        Skill
                      </th>
                      <th className="py-3 md:py-4 px-3 md:px-5 text-left font-['Nunito_Sans'] font-bold text-xs md:text-sm lg:text-base">
                        Topic Name
                      </th>
                      <th className="py-3 md:py-4 px-3 md:px-5 text-left font-['Nunito_Sans'] font-bold text-xs md:text-sm lg:text-base hidden sm:table-cell">
                        What we cover
                      </th>
                    </tr>
                  </thead>

                  {/* Table Body */}
                  <tbody>
                    {term.topics.map((topic, index) => (
                      <tr
                        key={topic.skill}
                        style={{
                          backgroundColor: index % 2 === 0 ? colors.light : "white"
                        }}
                      >
                        <td className="py-3 md:py-4 px-3 md:px-5 font-['Nunito_Sans'] text-xs md:text-sm lg:text-base text-[#070709] font-semibold">
                          {topic.skill}
                        </td>
                        <td className="py-3 md:py-4 px-3 md:px-5">
                          <Link href={`/curriculum/${yearParam}/${topic.name.toLowerCase().replace(/\s+/g, "-").replace(/&/g, "and")}`}>
                            <span className="font-['Nunito_Sans'] font-bold text-xs md:text-sm lg:text-base text-[#22a3d2] hover:underline cursor-pointer">
                              {topic.name}
                            </span>
                          </Link>
                        </td>
                        <td className="py-3 md:py-4 px-3 md:px-5 font-['Nunito_Sans'] text-xs md:text-sm lg:text-base text-[#070709] hidden sm:table-cell">
                          {topic.description}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          );
        })}
      </div>

      <CTASection />
      <Footer />
    </div>
  );
};
