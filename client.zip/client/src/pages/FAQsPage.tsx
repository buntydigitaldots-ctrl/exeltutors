import React, { useState } from "react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { CTASection } from "./sections/CTASection";
import { ChevronDown, ChevronUp } from "lucide-react";

const faqs = [
  {
    question: "What subjects do you offer tutoring for?",
    answer: "We offer tutoring in Maths and English for students from Year 2 to Year 10, as well as specialized NAPLAN preparation courses."
  },
  {
    question: "How are the tutoring sessions conducted?",
    answer: "All tutoring sessions are conducted online via our interactive virtual classroom. Students can attend from the comfort of their home using a computer or tablet."
  },
  {
    question: "What is the difference between 1-on-1 and group tutoring?",
    answer: "1-on-1 tutoring provides personalized attention with a dedicated tutor. Group tutoring (4:1) allows up to 4 students per session, offering a collaborative learning environment at a more affordable price."
  },
  {
    question: "How long is each tutoring session?",
    answer: "Each tutoring session is typically 60 minutes long. We've found this to be the optimal duration for maintaining student focus and engagement."
  },
  {
    question: "Can I book a free trial session?",
    answer: "Yes! We offer a free trial session for new students. This allows you and your child to experience our teaching style and meet your tutor before committing to a package."
  },
  {
    question: "How do I track my child's progress?",
    answer: "We provide regular progress reports and feedback after each session. Parents also have access to our parent portal where they can view session notes and progress tracking."
  },
  {
    question: "What if my child needs to reschedule a session?",
    answer: "We understand that schedules can change. You can reschedule sessions with at least 24 hours notice through our booking system at no additional charge."
  },
  {
    question: "Are your tutors qualified?",
    answer: "All our tutors are qualified teachers or education professionals with experience in their subject areas. They undergo thorough background checks and training before joining our team."
  }
];

export const FAQsPage = (): JSX.Element => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <div className="bg-white w-full min-h-screen">
      <Header showFreeTrial />

      <div className="w-full px-4 md:px-[100px] py-8 md:py-16">
        <h1 className="font-['Nunito_Sans'] font-extrabold text-3xl md:text-4xl lg:text-[50px] text-[#070709] text-center mb-3 md:mb-4">
          Frequently Asked Questions
        </h1>
        <p className="font-['Nunito_Sans'] text-sm md:text-base lg:text-xl text-[#070709] text-center mb-8 md:mb-16 max-w-2xl mx-auto">
          Find answers to common questions about our tutoring services
        </p>
        
        <div className="max-w-3xl mx-auto space-y-3 md:space-y-4">
          {faqs.map((faq, index) => (
            <div 
              key={index} 
              className="border border-gray-200 rounded-xl overflow-hidden"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between p-4 md:p-6 text-left hover:bg-gray-50 transition-colors"
              >
                <span className="font-['Nunito_Sans'] font-bold text-sm md:text-base lg:text-xl text-[#070709]">
                  {faq.question}
                </span>
                {openIndex === index ? (
                  <ChevronUp className="w-5 md:w-6 h-5 md:h-6 text-[#22a3d2] flex-shrink-0" />
                ) : (
                  <ChevronDown className="w-5 md:w-6 h-5 md:h-6 text-[#22a3d2] flex-shrink-0" />
                )}
              </button>
              {openIndex === index && (
                <div className="px-4 md:px-6 pb-4 md:pb-6">
                  <p className="font-['Nunito_Sans'] text-sm md:text-base lg:text-lg text-[#070709] leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      <CTASection />
      <Footer />
    </div>
  );
};
