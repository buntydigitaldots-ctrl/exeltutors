import React from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { CheckCircle } from "lucide-react";

export const NAPlaNSecondaryPage = (): JSX.Element => {
  return (
    <div className="bg-white w-full min-h-screen">
      <Header showFreeTrial />

      {/* Hero Section */}
      <div className="w-full bg-gradient-to-r from-[#d4f1f4] to-[#fff9e6] py-8 md:py-12">
        <div className="px-4 md:px-[100px]">
          <h1 className="font-['Nunito_Sans'] font-bold text-3xl md:text-4xl text-[#070709] mb-2">
            Secondary NAPLAN Tutoring for Years 7 & 9
          </h1>
          <p className="font-['Nunito_Sans'] text-sm md:text-base text-[#070709]">
            Sharpen literacy and numeracy skills while building strategies for test success.
          </p>
        </div>
      </div>

      <div className="w-full px-4 md:px-[100px] py-8 md:py-16">
        {/* What We Cover */}
        <div className="mb-12 md:mb-16">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] mb-10 text-center">
            What We Cover
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { title: "Reading", desc: "Work with longer and more complex texts, inference, evaluate arguments, synthesise ideas" },
              { title: "Writing", desc: "Strengthen persuasive and expository writing with structure, strong vocabulary, and mechanics" },
              { title: "Language Conventions", desc: "Focus on advanced spelling, grammar accuracy and style of expressions" },
              { title: "Numeracy", desc: "Apply algebra, proportional reasoning, statistics, and multi-step problem solving" }
            ].map((item, idx) => (
              <div key={idx} className="text-center">
                <div className="text-3xl mb-2">💡</div>
                <h3 className="font-['Nunito_Sans'] font-bold text-base text-[#070709] mb-1">{item.title}</h3>
                <p className="font-['Nunito_Sans'] text-xs text-[#070709]">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* How We Help Students Succeed */}
        <div className="mb-12 md:mb-16 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] mb-6">
              How We Help Students Succeed
            </h2>
            
            <div className="space-y-3">
              <div className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-[#22a3d2] flex-shrink-0 mt-0.5" />
                <p className="font-['Nunito_Sans'] text-base text-[#070709]">Diagnostic check to identify gaps in literacy and numeracy.</p>
              </div>
              <div className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-[#22a3d2] flex-shrink-0 mt-0.5" />
                <p className="font-['Nunito_Sans'] text-base text-[#070709]">Timed practice tests to improve accuracy and speed.</p>
              </div>
              <div className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-[#22a3d2] flex-shrink-0 mt-0.5" />
                <p className="font-['Nunito_Sans'] text-base text-[#070709]">Full simulated practice tests with detailed and actionable feedback.</p>
              </div>
              <div className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-[#22a3d2] flex-shrink-0 mt-0.5" />
                <p className="font-['Nunito_Sans'] text-base text-[#070709]">Focus on exam techniques: elimination, reasoning, time management.</p>
              </div>
              <div className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-[#22a3d2] flex-shrink-0 mt-0.5" />
                <p className="font-['Nunito_Sans'] text-base text-[#070709]">Parent progress updates after every stage</p>
              </div>
            </div>
          </div>
          
          <div className="bg-[#f5f5f5] h-[300px] rounded-xl flex items-center justify-center">
            <img src="/figmaAssets/placeholder-img.png" alt="Students" className="w-full h-full object-cover rounded-xl" />
          </div>
        </div>

        {/* When to Start Preparation */}
        <div className="mb-12 md:mb-16 bg-[#f0f8fb] p-8 rounded-xl">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] mb-4">
            When to Start Preparation
          </h2>
          
          <ul className="space-y-2">
            <li className="font-['Nunito_Sans'] text-base text-[#070709] flex gap-2">
              <span className="text-[#ff9e10]">•</span>
              <span>For Year 7 students, light preparation can begin in Year 6 Term 4, with focused work in Term 1 of Year 7.</span>
            </li>
            <li className="font-['Nunito_Sans'] text-base text-[#070709] flex gap-2">
              <span className="text-[#ff9e10]">•</span>
              <span>For Year 9 students, prep is best started in Year 8 Term 4, continuing into Term 1 of Year 9.</span>
            </li>
          </ul>
        </div>

        {/* Why Parents Choose Tutorexel */}
        <div className="mb-12 md:mb-16 bg-[#ff9e10] py-12 px-6 md:px-12 rounded-2xl">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-white text-center mb-10">
            Why Parents Choose Tutorexel
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { title: "Tailored support for secondary students who need more advanced practice", icon: "📚" },
              { title: "Tutors experienced in bridging schoolwork with NAPLAN requirements", icon: "🎯" },
              { title: "Flexible learning options: prep + group or one-to-one classes", icon: "⏰" }
            ].map((item, idx) => (
              <div key={idx} className="bg-white rounded-xl p-6 text-center">
                <p className="text-3xl mb-2">{item.icon}</p>
                <p className="font-['Nunito_Sans'] font-bold text-sm text-[#070709]">{item.title}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-[#22a3d2] text-white py-12 px-8 rounded-2xl text-center">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl mb-6">
            Experience the change today.
          </h2>
          <div className="flex gap-3 justify-center flex-wrap">
            <Link href="/contact">
              <Button className="bg-white text-[#22a3d2] hover:bg-gray-100 font-bold rounded-full">
                Book Your Free Trial Class
              </Button>
            </Link>
            <Link href="/signup">
              <Button className="bg-[#ff9e10] hover:bg-[#e68900] text-white font-bold rounded-full">
                Enroll on a tutoring plan
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};
