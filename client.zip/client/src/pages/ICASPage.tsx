import React, { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { CheckCircle } from "lucide-react";

export const ICASPage = (): JSX.Element => {
  return (
    <div className="bg-white w-full min-h-screen">
      <Header showFreeTrial />

      {/* Hero Section */}
      <div className="w-full bg-gradient-to-r from-[#d4f1f4] to-[#fff9e6] py-8 md:py-12">
        <div className="px-4 md:px-[100px]">
          <h1 className="font-['Nunito_Sans'] font-bold text-3xl md:text-4xl text-[#070709] mb-2">
            ICAS Preparation for Years 2-10
          </h1>
          <p className="font-['Nunito_Sans'] text-sm md:text-base text-[#070709]">
            Personalised support in English, Mathematics, Science, Writing, Digital and more
          </p>
        </div>
      </div>

      <div className="w-full px-4 md:px-[100px] py-8 md:py-16">
        {/* What is ICAS Section */}
        <div className="mb-12 md:mb-16">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] mb-6">
            What is ICAS?
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div className="space-y-4">
              <div className="flex gap-4">
                <CheckCircle className="w-6 h-6 text-[#22a3d2] flex-shrink-0 mt-1" />
                <div>
                  <p className="font-['Nunito_Sans'] font-bold text-base text-[#070709]">ICAS is the largest online assessment in Year 3-10</p>
                  <p className="font-['Nunito_Sans'] text-sm text-[#070709]">ICAS is one of our most requested courses</p>
                </div>
              </div>
              
              <div className="flex gap-4">
                <CheckCircle className="w-6 h-6 text-[#22a3d2] flex-shrink-0 mt-1" />
                <div>
                  <p className="font-['Nunito_Sans'] font-bold text-base text-[#070709]">Compete online & support alongside your school</p>
                  <p className="font-['Nunito_Sans'] text-sm text-[#070709]">Available in support alongside school education</p>
                </div>
              </div>
              
              <div className="flex gap-4">
                <CheckCircle className="w-6 h-6 text-[#22a3d2] flex-shrink-0 mt-1" />
                <div>
                  <p className="font-['Nunito_Sans'] font-bold text-base text-[#070709]">Results show your child has the logical reasoning and analytical skills</p>
                  <p className="font-['Nunito_Sans'] text-sm text-[#070709]">Results count globally and is widely recognised</p>
                </div>
              </div>
            </div>
            
            <div className="bg-[#f5f5f5] h-[300px] rounded-xl flex items-center justify-center">
              <img src="/figmaAssets/placeholder-img.png" alt="ICAS" className="w-full h-full object-cover rounded-xl" />
            </div>
          </div>
        </div>

        {/* Why ICAS Matters Section */}
        <div className="mb-12 md:mb-16 bg-[#ff9e10] py-12 px-6 md:px-12 rounded-2xl">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-white text-center mb-10">
            Why ICAS Matters?
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              { title: "Benchmarks academic skills", icon: "📊" },
              { title: "Recognised by schools and scholarships", icon: "🏆" },
              { title: "Motivation Students Succeed", icon: "⭐" },
              { title: "Certificates & High Distinction Top 1%", icon: "🎓" }
            ].map((item, idx) => (
              <div key={idx} className="bg-white rounded-xl p-6 text-center">
                <p className="text-3xl mb-2">{item.icon}</p>
                <p className="font-['Nunito_Sans'] font-bold text-sm text-[#070709]">{item.title}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Why ICAS Feels Challenging */}
        <div className="mb-12 md:mb-16">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] mb-4">
            Why ICAS Feels Challenging
          </h2>
          <p className="font-['Nunito_Sans'] text-base text-[#070709] mb-4">
            ICAS tests go beyond the school curriculum and challenge students to think critically and solve complex problems. Understanding the test format and practicing thoroughly can make a significant difference in performance.
          </p>
        </div>

        {/* How Tutorexcel Prepares Students */}
        <div className="mb-12 md:mb-16 bg-[#f0f8fb] p-8 rounded-xl">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] mb-6">
            How Tutorexcel Prepares Students
          </h2>
          
          <div className="space-y-4">
            <p className="font-['Nunito_Sans'] text-base text-[#070709]">
              At Tutorexcel, ICAS exam practice is naturally built into our regular English, Maths and Science tuition. Through worksheets, assessments and assignments, your child is directly developing the reasoning and problem-solving skills often without realising it.
            </p>
            
            <h3 className="font-['Nunito_Sans'] font-bold text-lg text-[#22a3d2] mt-6">From June onwards, we also run dedicated ICAS programs:</h3>
            
            <ul className="space-y-2">
              <li className="font-['Nunito_Sans'] text-base text-[#070709] flex gap-2">
                <span className="text-[#ff9e10]">•</span>
                <span>ICAS Prep Classes – Skills revision in English/Maths/Science</span>
              </li>
              <li className="font-['Nunito_Sans'] text-base text-[#070709] flex gap-2">
                <span className="text-[#ff9e10]">•</span>
                <span>Weekly ICAS mock tests closely modelled to the real exam</span>
              </li>
              <li className="font-['Nunito_Sans'] text-base text-[#070709] flex gap-2">
                <span className="text-[#ff9e10]">•</span>
                <span>Test taking strategies (timing, elimination, problem-solving)</span>
              </li>
              <li className="font-['Nunito_Sans'] text-base text-[#070709] flex gap-2">
                <span className="text-[#ff9e10]">•</span>
                <span>1:1 detailed mock tests with structured feedback</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Choose Your Level */}
        <div className="mb-12 md:mb-16">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] text-center mb-10">
            Choose Your Level
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Link href="/icas/primary">
              <div className="bg-[#05ac8f] text-white rounded-2xl p-8 text-center cursor-pointer hover:opacity-90 transition">
                <h3 className="font-['Nunito_Sans'] font-bold text-2xl mb-3">Primary</h3>
                <p className="font-['Nunito_Sans'] text-sm mb-6">Years 2-6<br/>Build strong foundations and test confidence</p>
                <Button className="bg-white text-[#05ac8f] hover:bg-gray-100 font-bold rounded-full">
                  Get Started
                </Button>
              </div>
            </Link>
            
            <Link href="/icas/secondary">
              <div className="bg-[#22a3d2] text-white rounded-2xl p-8 text-center cursor-pointer hover:opacity-90 transition">
                <h3 className="font-['Nunito_Sans'] font-bold text-2xl mb-3">Secondary</h3>
                <p className="font-['Nunito_Sans'] text-sm mb-6">Years 7-10<br/>Deepen reasoning, speed, and strategy skills</p>
                <Button className="bg-white text-[#22a3d2] hover:bg-gray-100 font-bold rounded-full">
                  Get Started
                </Button>
              </div>
            </Link>
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-[#ff9e10] text-white py-12 px-8 rounded-2xl text-center mb-12">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl mb-6">
            Your journey to better starts here.
          </h2>
          <div className="flex gap-3 justify-center flex-wrap">
            <Link href="/contact">
              <Button className="bg-white text-[#ff9e10] hover:bg-gray-100 font-bold rounded-full">
                Book Your Free Trial Class
              </Button>
            </Link>
            <Link href="/signup">
              <Button className="bg-[#22a3d2] hover:bg-[#1a8ab0] text-white font-bold rounded-full">
                Connect with us today
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};
