import React from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { CheckCircle } from "lucide-react";

export const ICASSecondaryPage = (): JSX.Element => {
  return (
    <div className="bg-white w-full min-h-screen">
      <Header showFreeTrial />

      {/* Hero Section */}
      <div className="w-full bg-gradient-to-r from-[#d4f1f4] to-[#fff9e6] py-8 md:py-12">
        <div className="px-4 md:px-[100px]">
          <h1 className="font-['Nunito_Sans'] font-bold text-3xl md:text-4xl text-[#070709] mb-2">
            ICAS Prep for Primary Students (Years 2-6)
          </h1>
          <p className="font-['Nunito_Sans'] text-sm md:text-base text-[#070709]">
            Gently build confidence in English, Maths, and Science while preparing for annual ICAS challenges.
          </p>
        </div>
      </div>

      <div className="w-full px-4 md:px-[100px] py-8 md:py-16">
        {/* What We Cover */}
        <div className="mb-12 md:mb-16">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] mb-10 text-center">
            What We Cover
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
            {[
              { title: "English", desc: "Analysis of longer and complex texts, extended writing, persuasion" },
              { title: "Mathematics", desc: "Algebra, proportional reasoning, advanced geometry, functions" },
              { title: "Science", desc: "Cells, ecosystems, energy transfer, chemical reactions, Earth systems" },
              { title: "Writing", desc: "Strong persuasive and narrative writing with structure and precision" },
              { title: "Digital Technologies", desc: "Text based coding algorithms, safe online, cybersecurity (Years 7-8)" },
              { title: "Spelling Bee", desc: "Advanced spelling, grammar accuracy and vocabulary" }
            ].map((item, idx) => (
              <div key={idx} className="text-center">
                <div className="text-3xl mb-2">💡</div>
                <h3 className="font-['Nunito_Sans'] font-bold text-base text-[#070709] mb-1">{item.title}</h3>
                <p className="font-['Nunito_Sans'] text-xs text-[#070709]">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* How We Help Students Succeed */}
        <div className="mb-12 md:mb-16 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] mb-6">
              How We Help Students Succeed
            </h2>
            
            <div className="space-y-3">
              <div className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-[#22a3d2] flex-shrink-0 mt-0.5" />
                <p className="font-['Nunito_Sans'] text-base text-[#070709]">Diagnostic check to identify gaps in English, Maths, and Science</p>
              </div>
              <div className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-[#22a3d2] flex-shrink-0 mt-0.5" />
                <p className="font-['Nunito_Sans'] text-base text-[#070709]">Timed practice tests to improve accuracy and speed</p>
              </div>
              <div className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-[#22a3d2] flex-shrink-0 mt-0.5" />
                <p className="font-['Nunito_Sans'] text-base text-[#070709]">Cut mock ICAS tests with detailed and actionable feedback</p>
              </div>
              <div className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-[#22a3d2] flex-shrink-0 mt-0.5" />
                <p className="font-['Nunito_Sans'] text-base text-[#070709]">Focus on exam techniques: elimination, reasoning, time management.</p>
              </div>
            </div>
          </div>
          
          <div className="bg-[#f5f5f5] h-[300px] rounded-xl flex items-center justify-center">
            <img src="/figmaAssets/placeholder-img.png" alt="Students" className="w-full h-full object-cover rounded-xl" />
          </div>
        </div>

        {/* When to Start Preparation */}
        <div className="mb-12 md:mb-16 bg-[#f0f8fb] p-8 rounded-xl">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] mb-4">
            When to Start Preparation
          </h2>
          
          <ul className="space-y-2">
            <li className="font-['Nunito_Sans'] text-base text-[#070709] flex gap-2">
              <span className="text-[#ff9e10]">•</span>
              <span>Light integration through the school year in our regular classes.</span>
            </li>
            <li className="font-['Nunito_Sans'] text-base text-[#070709] flex gap-2">
              <span className="text-[#ff9e10]">•</span>
              <span>Focused Prep Program runs June to August (each year).</span>
            </li>
            <li className="font-['Nunito_Sans'] text-base text-[#070709] flex gap-2">
              <span className="text-[#ff9e10]">•</span>
              <span>Students can come Prep + Mock or just take a Mock Test Only option.</span>
            </li>
          </ul>
        </div>

        {/* Why Parents Choose Tutorexel */}
        <div className="mb-12 md:mb-16 bg-[#ff9e10] py-12 px-6 md:px-12 rounded-2xl">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-white text-center mb-10">
            Why Parents Choose Tutorexel
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { title: "Secondary students need more than just content — they need strategies", icon: "📚" },
              { title: "Our tutors guide them through higher-order reasoning and problem-solving challenges", icon: "🎯" },
              { title: "Flexible learning options for busy secondary schedules", icon: "⏰" }
            ].map((item, idx) => (
              <div key={idx} className="bg-white rounded-xl p-6 text-center">
                <p className="text-3xl mb-2">{item.icon}</p>
                <p className="font-['Nunito_Sans'] font-bold text-sm text-[#070709]">{item.title}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-[#22a3d2] text-white py-12 px-8 rounded-2xl text-center">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl mb-6">
            Your journey to better starts here.
          </h2>
          <div className="flex gap-3 justify-center flex-wrap">
            <Link href="/contact">
              <Button className="bg-white text-[#22a3d2] hover:bg-gray-100 font-bold rounded-full">
                Book Your Free Trial Class
              </Button>
            </Link>
            <Link href="/signup">
              <Button className="bg-[#ff9e10] hover:bg-[#e68900] text-white font-bold rounded-full">
                Connect with us today
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};
