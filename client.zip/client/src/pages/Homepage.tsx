import React from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { HowItWorksSection } from "./sections/HowItWorksSection";
import { CourseCurriculumSection } from "./sections/CourseCurriculumSection";
import { TestimonialsSection } from "./sections/TestimonialsSection";
import { CTASection } from "./sections/CTASection";

const serviceCards = [
  {
    color: "#05ac8f",
    cloudSrc: "/figmaAssets/vector-1.svg",
    title: "Live Online",
    titleLine2: "Coaching",
    subtitle: "Mathematics, English",
    buttons: [
      { text: "Book a Demo Class", link: "/contact" },
      { text: "Sign Up", link: "/signup" },
    ],
  },
  {
    color: "#22a3d2",
    cloudSrc: "/figmaAssets/vector-8.svg",
    title: "Self",
    titleLine2: "Learning",
    subtitle: "Mathematics, English",
    buttons: [
      { text: "Try for Free", link: "/trial" },
      { text: "Sign Up", link: "/signup" },
    ],
  },
  {
    color: "#ff9e10",
    cloudSrc: "/figmaAssets/vector-2.svg",
    title: "Co-Curricular",
    titleLine2: "",
    subtitle: "Abacus, Piano, Guitar, Dance, Yoga",
    buttons: [
      { text: "Book a Demo Class", link: "/contact" },
      { text: "Sign Up", link: "/signup" },
    ],
  },
  {
    color: "#0f2a47",
    cloudSrc: "/figmaAssets/vector.svg",
    title: "NAPLAN",
    titleLine2: "Bootcamp",
    subtitle: "Year 3, Year 5, Year 7, Year 9",
    buttons: [
      { text: "Book a Demo Class", link: "/contact" },
      { text: "Sign Up", link: "/signup" },
    ],
  },
];

export const Homepage = (): JSX.Element => {
  return (
    <div className="bg-white w-full min-h-screen">
      <Header />

      <section className="relative w-full h-auto md:h-[450px] py-12 md:py-0">
        <img
          className="w-full h-40 md:h-full object-cover"
          alt="Banner"
          src="/figmaAssets/banner-image-1.png"
        />

        <div className="absolute top-4 md:top-[60px] left-0 w-full px-2 md:px-[86px]">
          <div className="flex flex-col md:flex-row justify-center gap-6 md:gap-2 lg:gap-3 max-w-[1567px] mx-auto">
            {serviceCards.map((card, index) => (
              <div key={index} className="relative w-full md:w-[280px] lg:w-[320px] xl:w-[360px] flex flex-col items-center">
                {/* Cloud Shape Container */}
                <div className="relative w-full h-[180px] md:h-[200px] flex items-center justify-center">
                  <img
                    className="absolute inset-0 w-full h-full object-contain"
                    alt="Cloud Background"
                    src={card.cloudSrc}
                  />

                  {/* Content inside cloud */}
                  <div className="relative z-10 flex flex-col items-center justify-center px-3 md:px-4 text-center w-full h-full">
                    <h3 className="font-['Nunito_Sans'] font-bold text-sm md:text-lg lg:text-xl leading-tight">
                      <span style={{ color: card.color }}>
                        {card.title}
                      </span>
                      {card.titleLine2 && (
                        <>
                          <br />
                          <span style={{ color: card.color }}>
                            {card.titleLine2}
                          </span>
                        </>
                      )}
                    </h3>

                    <p className="mt-1 font-['Nunito_Sans'] text-xs md:text-xs text-black leading-tight line-clamp-2">
                      {card.subtitle}
                    </p>

                    <Link href={`/curriculum/year-3`}>
                      <button className="mt-1.5 font-['Nunito_Sans'] font-bold text-xs text-black underline cursor-pointer hover:opacity-70 transition-opacity">
                        Learn More
                      </button>
                    </Link>
                  </div>
                </div>

                {/* Buttons below cloud */}
                <div className="flex flex-wrap justify-center gap-2 mt-3 w-full">
                  {card.buttons.map((btn, btnIndex) => (
                    <Link key={btnIndex} href={btn.link}>
                      <Button
                        className={`h-8 md:h-9 px-2 md:px-3 border-2 border-white rounded-full font-['Nunito_Sans'] font-bold text-white text-xs hover:opacity-90 transition-opacity`}
                        style={{ backgroundColor: card.color }}
                      >
                        {btn.text}
                      </Button>
                    </Link>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CourseCurriculumSection />
      <HowItWorksSection />
      <TestimonialsSection />
      <CTASection />
      <Footer />
    </div>
  );
};
