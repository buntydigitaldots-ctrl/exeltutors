import React, { useState } from "react";
import { Link, useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";

const questions = [
  {
    id: 1,
    question: "Lorem ipsum dolor sit amet consectetur. Semper ac condimentum a sit molestie dictum. In fermentum aliquam a curabitur dui. Nunc nunc id nulla feugiat.",
    options: [
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
    ],
    correctAnswer: 0,
    explanation: "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel."
  },
  {
    id: 2,
    question: "Lorem ipsum dolor sit amet consectetur. Semper ac condimentum a sit molestie dictum. In fermentum aliquam a curabitur dui. Nunc nunc id nulla feugiat.",
    options: [
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
    ],
    correctAnswer: 1,
    explanation: "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel."
  },
  {
    id: 3,
    question: "Lorem ipsum dolor sit amet consectetur. Semper ac condimentum a sit molestie dictum. In fermentum aliquam a curabitur dui. Nunc nunc id nulla feugiat.",
    options: [
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
    ],
    correctAnswer: 2,
    explanation: "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel."
  },
  {
    id: 4,
    question: "Lorem ipsum dolor sit amet consectetur. Semper ac condimentum a sit molestie dictum. In fermentum aliquam a curabitur dui. Nunc nunc id nulla feugiat.",
    options: [
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
    ],
    correctAnswer: 0,
    explanation: "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel."
  },
  {
    id: 5,
    question: "Lorem ipsum dolor sit amet consectetur. Semper ac condimentum a sit molestie dictum. In fermentum aliquam a curabitur dui. Nunc nunc id nulla feugiat.",
    options: [
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
    ],
    correctAnswer: 1,
    explanation: "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel."
  },
  {
    id: 6,
    question: "Lorem ipsum dolor sit amet consectetur. Semper ac condimentum a sit molestie dictum. In fermentum aliquam a curabitur dui. Nunc nunc id nulla feugiat.",
    options: [
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
    ],
    correctAnswer: 3,
    explanation: "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel."
  },
  {
    id: 7,
    question: "Lorem ipsum dolor sit amet consectetur. Semper ac condimentum a sit molestie dictum. In fermentum aliquam a curabitur dui. Nunc nunc id nulla feugiat.",
    options: [
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
      "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel.",
    ],
    correctAnswer: 2,
    explanation: "Lorem ipsum dolor sit amet consectetur. Proin at ut vel imperdiet amet fringilla. Quam sapien vestibulum vel non vel."
  },
];

export const PracticeTestPage = (): JSX.Element => {
  const params = useParams();
  const yearParam = params.year || "year-3";
  const topicParam = params.topic || "purpose-and-main-idea";
  const currentYear = yearParam.replace("-", " ").replace(/\b\w/g, l => l.toUpperCase());
  const topicName = topicParam.replace(/-/g, " ").replace(/\b\w/g, l => l.toUpperCase()).replace(" And ", " & ");
  
  const [selectedAnswers, setSelectedAnswers] = useState<{[key: number]: number}>({});
  const [showResults, setShowResults] = useState(false);
  const [showModal, setShowModal] = useState(false);

  const handleSelectAnswer = (questionId: number, optionIndex: number) => {
    setSelectedAnswers(prev => ({
      ...prev,
      [questionId]: optionIndex
    }));
  };

  const handleSubmit = () => {
    setShowResults(true);
    setShowModal(true);
  };

  return (
    <div className="bg-white w-full min-h-screen">
      <Header showFreeTrial />

      <div className="w-full px-4 md:px-[100px] py-6 md:py-8">
        <div className="flex flex-col sm:flex-row gap-2 md:gap-4 mb-6 md:mb-8">
          <button className="px-6 md:px-8 py-2 md:py-3 rounded-full font-['Nunito_Sans'] font-bold text-sm md:text-lg bg-[#22a3d2] text-white">
            Maths
          </button>
          <button className="px-6 md:px-8 py-2 md:py-3 rounded-full font-['Nunito_Sans'] font-bold text-sm md:text-lg bg-gray-100 text-[#070709]">
            English
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-1 md:gap-2 text-sm md:text-xl font-['Nunito_Sans'] mb-6 md:mb-8 overflow-x-auto">
          <Link href={`/curriculum/${yearParam}`}>
            <span className="text-[#070709] hover:text-[#22a3d2] cursor-pointer whitespace-nowrap">{currentYear}</span>
          </Link>
          <span className="text-gray-400">{">"}</span>
          <span className="text-[#22a3d2] font-bold whitespace-nowrap">{topicName}</span>
        </div>

        <div className="bg-gray-50 rounded-lg p-4 md:p-8 mb-6 md:mb-8">
          <h2 className="font-['Nunito_Sans'] font-bold text-xl md:text-2xl lg:text-3xl text-[#070709] mb-2 md:mb-4">
            Practice Test
          </h2>
        </div>

        <div className="space-y-6 md:space-y-8">
          {questions.map((q, qIndex) => (
            <div key={q.id} className="bg-white border border-gray-200 rounded-lg p-4 md:p-8">
              <h3 className="font-['Nunito_Sans'] font-bold text-base md:text-lg lg:text-xl text-[#070709] mb-4 md:mb-6">
                Q{q.id}. {q.question}
              </h3>

              <div className="space-y-3 md:space-y-4">
                {q.options.map((option, optIndex) => {
                  const isSelected = selectedAnswers[q.id] === optIndex;
                  const isCorrect = showResults && optIndex === q.correctAnswer;
                  const isWrong = showResults && isSelected && optIndex !== q.correctAnswer;

                  return (
                    <label
                      key={optIndex}
                      className={`flex items-start gap-3 md:gap-4 p-3 md:p-4 rounded-lg cursor-pointer transition-colors ${
                        isCorrect
                          ? "bg-green-50 border-2 border-green-500"
                          : isWrong
                          ? "bg-red-50 border-2 border-red-500"
                          : isSelected
                          ? "bg-blue-50 border-2 border-[#22a3d2]"
                          : "bg-gray-50 hover:bg-gray-100 border-2 border-transparent"
                      }`}
                    >
                      <input
                        type="radio"
                        name={`question-${q.id}`}
                        checked={isSelected}
                        onChange={() => handleSelectAnswer(q.id, optIndex)}
                        className="mt-1 w-4 md:w-5 h-4 md:h-5"
                        disabled={showResults}
                      />
                      <span className="font-['Nunito_Sans'] text-sm md:text-base lg:text-lg text-[#070709]">{option}</span>
                    </label>
                  );
                })}
              </div>

              {showResults && selectedAnswers[q.id] !== undefined && (
                <div className="mt-4 md:mt-6 p-3 md:p-4 bg-yellow-50 rounded-lg">
                  <p className="font-['Nunito_Sans'] font-bold text-sm md:text-base lg:text-lg text-[#070709]">
                    Explanation: {q.explanation}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>

        {!showResults && (
          <div className="flex justify-center mt-8 md:mt-12">
            <Button
              onClick={handleSubmit}
              className="h-10 md:h-[60px] px-6 md:px-12 bg-[#ff9e10] hover:bg-[#ff9e10]/90 rounded-full font-['Nunito_Sans'] font-bold text-white text-sm md:text-xl"
            >
              Submit Answers
            </Button>
          </div>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-12 max-w-lg text-center">
            <h2 className="font-['Nunito_Sans'] font-bold text-4xl text-[#070709] mb-8">
              Well Done.
            </h2>
            <div className="flex flex-col gap-4">
              <Link href="/contact">
                <Button className="w-full h-[60px] bg-[#ff9e10] hover:bg-[#ff9e10]/90 rounded-full font-['Nunito_Sans'] font-bold text-white text-xl">
                  Book Your Free Trial Class
                </Button>
              </Link>
              <Link href={`/curriculum/${yearParam}`}>
                <Button variant="outline" className="w-full h-[60px] rounded-full font-['Nunito_Sans'] font-bold text-xl border-2 border-[#070709]">
                  Learn More
                </Button>
              </Link>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
};
