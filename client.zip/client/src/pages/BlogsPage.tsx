import React from "react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { CTASection } from "./sections/CTASection";

const blogPosts = [
  {
    title: "5 Tips to Help Your Child Excel in Maths",
    date: "November 15, 2024",
    excerpt: "Discover proven strategies to boost your child's mathematical skills and confidence.",
    image: "/figmaAssets/rectangle-48.png"
  },
  {
    title: "The Importance of Reading Comprehension",
    date: "November 10, 2024",
    excerpt: "Learn how strong reading skills form the foundation for academic success.",
    image: "/figmaAssets/rectangle-49.png"
  },
  {
    title: "Preparing for NAPLAN: A Parent's Guide",
    date: "November 5, 2024",
    excerpt: "Everything you need to know to help your child prepare for NAPLAN tests.",
    image: "/figmaAssets/rectangle-50.png"
  }
];

export const BlogsPage = (): JSX.Element => {
  return (
    <div className="bg-white w-full min-h-screen">
      <Header showFreeTrial />

      <div className="w-full px-4 md:px-[100px] py-8 md:py-16">
        <h1 className="font-['Nunito_Sans'] font-extrabold text-3xl md:text-4xl lg:text-[50px] text-[#070709] text-center mb-3 md:mb-4">
          Our Blog
        </h1>
        <p className="font-['Nunito_Sans'] text-sm md:text-base lg:text-xl text-[#070709] text-center mb-8 md:mb-16 max-w-2xl mx-auto">
          Tips, insights, and resources to help your child succeed academically
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 lg:gap-8 max-w-6xl mx-auto">
          {blogPosts.map((post, index) => (
            <div key={index} className="bg-gray-50 rounded-2xl overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
              <div className="h-32 md:h-40 lg:h-48 bg-gray-200"></div>
              <div className="p-4 md:p-6">
                <p className="font-['Nunito_Sans'] text-xs md:text-sm text-[#22a3d2] mb-2">{post.date}</p>
                <h3 className="font-['Nunito_Sans'] font-bold text-base md:text-lg lg:text-xl text-[#070709] mb-2 md:mb-3">{post.title}</h3>
                <p className="font-['Nunito_Sans'] text-xs md:text-sm lg:text-base text-[#070709]">{post.excerpt}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <CTASection />
      <Footer />
    </div>
  );
};
