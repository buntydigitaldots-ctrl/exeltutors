import React from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { CheckCircle } from "lucide-react";

export const PianoPage = (): JSX.Element => {
  return (
    <div className="bg-white w-full min-h-screen">
      <Header showFreeTrial />

      {/* Hero Section with Piano Image */}
      <div className="w-full bg-black relative h-[250px] md:h-[350px] flex items-end">
        <div className="w-full h-[120px] md:h-[160px] bg-repeat-x" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 88 32%27%3E%3Crect width=%2788%27 height=%2732%27 fill=%27%23fff%27/%3E%3C/svg%3E")' }} />
      </div>

      {/* Content */}
      <div className="w-full px-4 md:px-[100px] py-8 md:py-16">
        {/* Title */}
        <div className="mb-12 md:mb-16">
          <h1 className="font-['Nunito_Sans'] font-bold text-3xl md:text-4xl text-[#070709] mb-2">
            Learn Piano Online with Tutorexcel
          </h1>
          <p className="font-['Nunito_Sans'] text-sm md:text-base text-[#070709] mb-6">
            Start your music journey following the internationally recognised Trinity College London method.
          </p>
          <Link href="/contact">
            <Button className="bg-[#ff9e10] hover:bg-[#e68900] text-white font-bold rounded-full">
              Book Your Free Trial Class
            </Button>
          </Link>
        </div>

        {/* About Our Piano Classes */}
        <div className="mb-12 md:mb-16 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] mb-6">
              About Our Piano Classes
            </h2>
            
            <div className="space-y-3">
              <div className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-[#05ac8f] flex-shrink-0 mt-0.5" />
                <p className="font-['Nunito_Sans'] text-base text-[#070709]">Lessons taught by qualified tutors with extensive music education background</p>
              </div>
              <div className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-[#05ac8f] flex-shrink-0 mt-0.5" />
                <p className="font-['Nunito_Sans'] text-base text-[#070709]">Structured curriculum aligned with Trinity College London Graded Exams for Music</p>
              </div>
              <div className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-[#05ac8f] flex-shrink-0 mt-0.5" />
                <p className="font-['Nunito_Sans'] text-base text-[#070709]">Personalized approach catering to all ages and skill levels</p>
              </div>
              <div className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-[#05ac8f] flex-shrink-0 mt-0.5" />
                <p className="font-['Nunito_Sans'] text-base text-[#070709]">Online lessons providing flexibility and accessibility</p>
              </div>
            </div>
          </div>
          
          <div className="bg-[#f5f5f5] h-[300px] rounded-xl flex items-center justify-center">
            <img src="/figmaAssets/placeholder-img.png" alt="Piano" className="w-full h-full object-cover rounded-xl" />
          </div>
        </div>

        {/* Why Choose Piano Lessons */}
        <div className="mb-12 md:mb-16 bg-[#05ac8f] py-12 px-6 md:px-12 rounded-2xl">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-white text-center mb-10">
            Why Choose Tutorexel Piano Lessons?
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              { title: "Qualified Tutors", icon: "👨‍🏫" },
              { title: "Structured Programs", icon: "📚" },
              { title: "Flexible Scheduling", icon: "⏰" },
              { title: "Globally Recognised", icon: "🌍" }
            ].map((item, idx) => (
              <div key={idx} className="bg-white rounded-xl p-6 text-center">
                <p className="text-3xl mb-2">{item.icon}</p>
                <p className="font-['Nunito_Sans'] font-bold text-sm text-[#070709]">{item.title}</p>
              </div>
            ))}
          </div>
        </div>

        {/* What You'll Learn */}
        <div className="mb-12 md:mb-16">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] mb-6">
            What You'll Learn
          </h2>
          
          <ul className="space-y-2">
            <li className="font-['Nunito_Sans'] text-base text-[#070709] flex gap-2">
              <span className="text-[#ff9e10]">•</span>
              <span>Technique, accuracy, scales, arpeggios and sight-reading</span>
            </li>
            <li className="font-['Nunito_Sans'] text-base text-[#070709] flex gap-2">
              <span className="text-[#ff9e10]">•</span>
              <span>Grade-appropriate repertoire from classical to contemporary</span>
            </li>
            <li className="font-['Nunito_Sans'] text-base text-[#070709] flex gap-2">
              <span className="text-[#ff9e10]">•</span>
              <span>Music theory and understanding chord progressions</span>
            </li>
            <li className="font-['Nunito_Sans'] text-base text-[#070709] flex gap-2">
              <span className="text-[#ff9e10]">•</span>
              <span>Performance skills and exam preparation (if desired)</span>
            </li>
          </ul>
        </div>

        {/* Class Format */}
        <div className="mb-12 md:mb-16 bg-[#fff9e6] p-8 rounded-xl">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] mb-6">
            Class Format
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { title: "Weekly live one-on-one lessons", desc: "30, 45 or 60 minute sessions" },
              { title: "Curated music assignments after each class", desc: "Practice materials and worksheets" },
              { title: "Regular progress reviews", desc: "Updates to parents after each stage" }
            ].map((item, idx) => (
              <div key={idx} className="bg-white border-2 border-[#ff9e10] rounded-xl p-6">
                <h3 className="font-['Nunito_Sans'] font-bold text-base text-[#ff9e10] mb-2">{item.title}</h3>
                <p className="font-['Nunito_Sans'] text-sm text-[#070709]">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Who Can Join */}
        <div className="mb-12 md:mb-16">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] mb-4">
            Who Can Join?
          </h2>
          
          <ul className="space-y-2">
            <li className="font-['Nunito_Sans'] text-base text-[#070709]">
              <span className="font-bold">Children (Ages 5+):</span> Beginning piano with music reading basics
            </li>
            <li className="font-['Nunito_Sans'] text-base text-[#070709]">
              <span className="font-bold">Students:</span> Currently learning piano who want to boost skills or work towards exams
            </li>
            <li className="font-['Nunito_Sans'] text-base text-[#070709]">
              <span className="font-bold">Adults:</span> Hobby learners or music enthusiasts learning from scratch or restarting

            </li>
          </ul>
        </div>

        {/* Trinity College London */}
        <div className="mb-12 md:mb-16 bg-[#f0f8fb] p-8 rounded-xl">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] mb-6">
            Pathway with Trinity College London
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[
              { title: "Entry Level", desc: "Begin your musical journey" },
              { title: "Grades 1-3", desc: "Foundation of pianistic skills" },
              { title: "Grades 4-6", desc: "Intermediate technique and interpretation" },
              { title: "Grades 7-8", desc: "Advanced skills and artistry" }
            ].map((item, idx) => (
              <div key={idx} className="text-center">
                <h3 className="font-['Nunito_Sans'] font-bold text-base text-[#22a3d2] mb-2">{item.title}</h3>
                <p className="font-['Nunito_Sans'] text-sm text-[#070709]">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Why Parents Love Tutorexel Music */}
        <div className="mb-12 md:mb-16 bg-[#ff9e10] py-12 px-6 md:px-12 rounded-2xl">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-white text-center mb-10">
            Why Parents Love Tutorexel Music Lessons
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              { title: "Safe and supportive online environment", icon: "🛡️" },
              { title: "Clear practice piano experience from professionals", icon: "👨‍🏫" },
              { title: "Preparation for international exams", icon: "🎓" },
              { title: "The joy of building confidence in self-expression", icon: "✨" }
            ].map((item, idx) => (
              <div key={idx} className="bg-white rounded-xl p-6 text-center">
                <p className="text-3xl mb-2">{item.icon}</p>
                <p className="font-['Nunito_Sans'] font-bold text-sm text-[#070709]">{item.title}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-[#22a3d2] text-white py-12 px-8 rounded-2xl text-center">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl mb-6">
            Ready to Begin Your Musical Journey?
          </h2>
          <div className="flex gap-3 justify-center flex-wrap">
            <Link href="/contact">
              <Button className="bg-white text-[#22a3d2] hover:bg-gray-100 font-bold rounded-full">
                Book Your Free Trial Class
              </Button>
            </Link>
            <Link href="/signup">
              <Button className="bg-[#ff9e10] hover:bg-[#e68900] text-white font-bold rounded-full">
                Enroll in Piano Lessons
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};
