import React from "react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { CTASection } from "./sections/CTASection";

export const AboutPage = (): JSX.Element => {
  return (
    <div className="bg-white w-full min-h-screen">
      <Header showFreeTrial />

      <div className="w-full px-4 md:px-[100px] py-8 md:py-16">
        <h1 className="font-['Nunito_Sans'] font-extrabold text-3xl md:text-4xl lg:text-[50px] text-[#070709] text-center mb-6 md:mb-8">
          About TutorExel
        </h1>
        
        <div className="max-w-4xl mx-auto">
          <p className="font-['Nunito_Sans'] text-sm md:text-base lg:text-xl text-[#070709] leading-relaxed mb-6">
            TutorExel is a leading online tutoring platform dedicated to helping Australian students excel in Maths and English. We provide personalized learning experiences tailored to each student's needs, aligned with the Australian National Curriculum.
          </p>
          
          <h2 className="font-['Nunito_Sans'] font-bold text-xl md:text-2xl lg:text-3xl text-[#22a3d2] mb-3 md:mb-4 mt-8 md:mt-12">
            Our Mission
          </h2>
          <p className="font-['Nunito_Sans'] text-sm md:text-base lg:text-xl text-[#070709] leading-relaxed mb-6">
            To empower every student with the knowledge, skills, and confidence they need to succeed academically and beyond.
          </p>
          
          <h2 className="font-['Nunito_Sans'] font-bold text-xl md:text-2xl lg:text-3xl text-[#22a3d2] mb-3 md:mb-4 mt-8 md:mt-12">
            Why Choose Us
          </h2>
          <ul className="space-y-3 md:space-y-4">
            <li className="flex items-start gap-3">
              <span className="text-[#ff9e10] text-xl md:text-2xl flex-shrink-0">✓</span>
              <span className="font-['Nunito_Sans'] text-sm md:text-base lg:text-xl text-[#070709]">Expert tutors with years of teaching experience</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-[#ff9e10] text-xl md:text-2xl flex-shrink-0">✓</span>
              <span className="font-['Nunito_Sans'] text-sm md:text-base lg:text-xl text-[#070709]">1-on-1 and small group (4:1) tutoring options</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-[#ff9e10] text-xl md:text-2xl flex-shrink-0">✓</span>
              <span className="font-['Nunito_Sans'] text-sm md:text-base lg:text-xl text-[#070709]">Curriculum aligned with Australian National Curriculum</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-[#ff9e10] text-xl md:text-2xl flex-shrink-0">✓</span>
              <span className="font-['Nunito_Sans'] text-sm md:text-base lg:text-xl text-[#070709]">Flexible online sessions from the comfort of home</span>
            </li>
          </ul>
        </div>
      </div>

      <CTASection />
      <Footer />
    </div>
  );
};
