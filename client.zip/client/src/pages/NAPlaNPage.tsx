import React from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";

export const NAPlaNPage = (): JSX.Element => {
  return (
    <div className="bg-white w-full min-h-screen">
      <Header showFreeTrial />

      {/* Hero Section */}
      <div className="w-full bg-gradient-to-r from-[#d4f1f4] to-[#fff9e6] py-8 md:py-12">
        <div className="px-4 md:px-[100px]">
          <h1 className="font-['Nunito_Sans'] font-bold text-3xl md:text-4xl text-[#070709] mb-2">
            NAPLAN Tutoring for Years 3, 5, 7 & 9
          </h1>
          <p className="font-['Nunito_Sans'] text-sm md:text-base text-[#070709]">
            Personalised preparation in literacy and numeracy to help your child test confidently and ready for the test.
          </p>
        </div>
      </div>

      <div className="w-full px-4 md:px-[100px] py-8 md:py-16">
        {/* What is NAPLAN */}
        <div className="mb-12 md:mb-16 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] mb-4">
              What is NAPLAN?
            </h2>
            <p className="font-['Nunito_Sans'] text-base text-[#070709] mb-4">
              The National Assessment Program Literacy and Numeracy (NAPLAN) is a yearly national assessment for students in Years 3, 5, 7 and 9. It tests reading, writing, language conventions, and numeracy skills in English across all Australian schools.
            </p>
            
            <div className="space-y-2">
              <div className="flex gap-2">
                <span className="text-[#22a3d2] font-bold">•</span>
                <span className="font-['Nunito_Sans'] text-sm text-[#070709]">Reading</span>
              </div>
              <div className="flex gap-2">
                <span className="text-[#22a3d2] font-bold">•</span>
                <span className="font-['Nunito_Sans'] text-sm text-[#070709]">Writing</span>
              </div>
              <div className="flex gap-2">
                <span className="text-[#22a3d2] font-bold">•</span>
                <span className="font-['Nunito_Sans'] text-sm text-[#070709]">Language Conventions (Spelling, punctuation, grammar)</span>
              </div>
              <div className="flex gap-2">
                <span className="text-[#22a3d2] font-bold">•</span>
                <span className="font-['Nunito_Sans'] text-sm text-[#070709]">Numeracy</span>
              </div>
            </div>
          </div>
          
          <div className="bg-[#f5f5f5] h-[300px] rounded-xl flex items-center justify-center">
            <img src="/figmaAssets/placeholder-img.png" alt="NAPLAN" className="w-full h-full object-cover rounded-xl" />
          </div>
        </div>

        {/* Why Preparation Matters */}
        <div className="mb-12 md:mb-16 bg-[#ff9e10] py-12 px-6 md:px-12 rounded-2xl">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-white text-center mb-10">
            Why Preparation Matters
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              { title: "Strengthen Literacy and Numeracy Skills", icon: "📖" },
              { title: "Become Confident in the NAPLAN-style questions", icon: "✨" },
              { title: "Learn simple strategies for managing time and exam pressure", icon: "⏱️" },
              { title: "Sit the test feeling calm and prepared", icon: "😌" }
            ].map((item, idx) => (
              <div key={idx} className="bg-white rounded-xl p-6 text-center">
                <p className="text-3xl mb-2">{item.icon}</p>
                <p className="font-['Nunito_Sans'] font-bold text-sm text-[#070709]">{item.title}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Our Approach */}
        <div className="mb-12 md:mb-16">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] text-center mb-10">
            Our Approach
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              { title: "Skills Revision", desc: "We start with a skills audit, identifying and tailoring your child's needs." },
              { title: "Individualised Lessons", desc: "Targeted lessons are run 1:1 or in small groups." },
              { title: "Guided Feedback", desc: "Guided feedback from our experienced tutors." },
              { title: "Ongoing Support", desc: "Regular progress updates for parents and ongoing support." }
            ].map((item, idx) => (
              <div key={idx} className="text-center bg-[#f0f8fb] p-6 rounded-xl">
                <h3 className="font-['Nunito_Sans'] font-bold text-base text-[#070709] mb-2">{item.title}</h3>
                <p className="font-['Nunito_Sans'] text-sm text-[#070709]">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Choose Your Level */}
        <div className="mb-12 md:mb-16">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] text-center mb-10">
            Choose Your Level
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Link href="/naplan/primary">
              <div className="bg-[#05ac8f] text-white rounded-2xl p-8 text-center cursor-pointer hover:opacity-90 transition">
                <h3 className="font-['Nunito_Sans'] font-bold text-2xl mb-3">Primary</h3>
                <p className="font-['Nunito_Sans'] text-sm mb-6">Years 3 & 5<br/>Focus on building core literacy and numeracy foundations.</p>
                <Button className="bg-white text-[#05ac8f] hover:bg-gray-100 font-bold rounded-full">
                  Get Started
                </Button>
              </div>
            </Link>
            
            <Link href="/naplan/secondary">
              <div className="bg-[#22a3d2] text-white rounded-2xl p-8 text-center cursor-pointer hover:opacity-90 transition">
                <h3 className="font-['Nunito_Sans'] font-bold text-2xl mb-3">Secondary</h3>
                <p className="font-['Nunito_Sans'] text-sm mb-6">Years 7 & 9<br/>Focus on advanced skills, reasoning, and exam strategies.</p>
                <Button className="bg-white text-[#22a3d2] hover:bg-gray-100 font-bold rounded-full">
                  Get Started
                </Button>
              </div>
            </Link>
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-[#ff9e10] text-white py-12 px-8 rounded-2xl text-center">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl mb-6">
            Experience the change today.
          </h2>
          <div className="flex gap-3 justify-center flex-wrap">
            <Link href="/contact">
              <Button className="bg-white text-[#ff9e10] hover:bg-gray-100 font-bold rounded-full">
                Book Your Free Trial Class
              </Button>
            </Link>
            <Link href="/signup">
              <Button className="bg-[#22a3d2] hover:bg-[#1a8ab0] text-white font-bold rounded-full">
                Enroll on a tutoring plan
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};
