import React, { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Check } from "lucide-react";

const offerings = [
  {
    id: "live-coaching",
    title: "Live Online",
    subtitle: "Coaching",
    color: "#05ac8f",
    features: [
      "1:1 or 3:1 classes",
      "Transparent learning structure",
      "Comprehensive course content",
      "Weekly practice worksheets",
      "Free assessment & report",
      "Regular term tests",
      "Biannual mega exams",
      "Flexible scheduling & make-ups",
      "All-in-one learning platform"
    ]
  },
  {
    id: "self-learning",
    title: "Self",
    subtitle: "Learning",
    color: "#22a3d2",
    features: [
      "Curriculum transparency & skills",
      "Term-wise structured catalogue",
      "Comprehensive course content",
      "Weekly practice worksheets",
      "Term & mega exams"
    ]
  },
  {
    id: "co-curricular",
    title: "Co-Curricular",
    subtitle: "",
    color: "#ff9e10",
    features: [
      "1:1 or 3:1 classes",
      "Transparent learning structure",
      "Comprehensive course content",
      "Weekly practice worksheets",
      "Free assessment & report",
      "Regular term tests",
      "Biannual mega exams",
      "Flexible scheduling & make-ups",
      "All-in-one learning platform"
    ]
  },
  {
    id: "naplan",
    title: "NAPLAN",
    subtitle: "Bootcamp",
    color: "#0f2a47",
    features: [
      "10 NAPLAN coaching sessions",
      "NAPLAN practice worksheets",
      "2 full mock exams",
      "Structured NAPLAN material",
      "Self-practice NAPLAN tests"
    ]
  }
];

export const PricingPage = (): JSX.Element => {
  const [selectedOffering, setSelectedOffering] = useState<string>("live-coaching");

  return (
    <div className="bg-white w-full min-h-screen">
      <Header showFreeTrial />

      {/* Hero Section */}
      <div className="w-full bg-gradient-to-r from-[#d4f1f4] to-[#fff9e6] py-8 md:py-12">
        <div className="px-4 md:px-[100px]">
          <h1 className="font-['Nunito_Sans'] font-bold text-4xl md:text-5xl text-[#070709]">
            Pricing
          </h1>
        </div>
      </div>

      <div className="w-full px-4 md:px-[100px] py-8 md:py-12">
        {/* Our Offerings Section */}
        <div className="mb-8 md:mb-12">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] mb-4">
            Our Offerings
          </h2>
          <p className="font-['Nunito_Sans'] text-sm md:text-base text-[#070709] max-w-5xl leading-relaxed">
            Every family begins with a free trial class so you can experience Tutorexel with no commitment. After your trial, you can choose either One-to-One Tutoring or Group Classes. <span className="font-bold">All sessions are 1 hour. Payments are billed monthly in advance. Cancel anytime with 2 weeks' notice.</span>
          </p>
        </div>

        {/* Service Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-8 md:mb-12">
          {offerings.map((offering) => (
            <div
              key={offering.id}
              className="rounded-2xl p-5 md:p-6 cursor-pointer transition-all text-white"
              style={{ backgroundColor: offering.color }}
              onClick={() => setSelectedOffering(offering.id)}
            >
              <h3 className="font-['Nunito_Sans'] font-bold text-lg md:text-2xl mb-0">
                {offering.title}
              </h3>
              {offering.subtitle && (
                <h4 className="font-['Nunito_Sans'] font-bold text-lg md:text-2xl mb-3 md:mb-4">
                  {offering.subtitle}
                </h4>
              )}
              
              <ul className="space-y-2 mb-5 md:mb-6">
                {offering.features.map((feature, index) => (
                  <li key={index} className="flex items-start gap-2 font-['Nunito_Sans'] text-xs md:text-sm text-white">
                    <Check className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              <Button
                className="w-full h-9 md:h-10 rounded-full font-['Nunito_Sans'] font-bold text-sm md:text-base bg-white text-gray-900 hover:bg-gray-100"
              >
                Select
              </Button>
            </div>
          ))}
        </div>

        {/* Pricing Section - Dynamic based on selected offering */}
        {selectedOffering === "live-coaching" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-8">
            {/* 1:1 Coaching */}
            <div className="border-2 border-[#05ac8f] rounded-2xl p-6 md:p-8">
              <h3 className="font-['Nunito_Sans'] font-bold text-lg md:text-2xl text-[#05ac8f] mb-6">
                1:1 Coaching
              </h3>
              
              <div className="space-y-4 mb-6">
                <div>
                  <p className="font-['Nunito_Sans'] text-sm text-gray-600 mb-2">1 Subject</p>
                  <p className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-black">$84 <span className="text-sm md:text-base font-normal text-gray-600">AUD/month</span></p>
                </div>
                <div>
                  <p className="font-['Nunito_Sans'] text-sm text-gray-600 mb-2">2 Subjects</p>
                  <p className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-black">$149 <span className="text-sm md:text-base font-normal text-gray-600">AUD/month</span></p>
                </div>
              </div>

              <div className="bg-[#05ac8f] text-white rounded-xl p-4 md:p-6 text-center mb-6">
                <p className="font-['Nunito_Sans'] font-bold text-lg md:text-2xl">4</p>
                <p className="font-['Nunito_Sans'] text-sm">Sessions per Month per Subject</p>
              </div>

              <div className="flex gap-3 justify-center">
                <Link href="/contact">
                  <Button className="h-10 md:h-11 px-6 md:px-8 bg-[#ff9e10] hover:bg-[#ff9e10]/90 rounded-full font-['Nunito_Sans'] font-bold text-white text-sm">
                    Book a Demo Class
                  </Button>
                </Link>
                <Link href="/signup">
                  <Button className="h-10 md:h-11 px-6 md:px-8 bg-[#05ac8f] hover:bg-[#05ac8f]/90 rounded-full font-['Nunito_Sans'] font-bold text-white text-sm">
                    Join
                  </Button>
                </Link>
              </div>
            </div>

            {/* Group Coaching */}
            <div className="border-2 border-[#05ac8f] rounded-2xl p-6 md:p-8">
              <h3 className="font-['Nunito_Sans'] font-bold text-lg md:text-2xl text-[#05ac8f] mb-6">
                Group Coaching (3:1)
              </h3>
              
              <div className="space-y-4 mb-6">
                <div>
                  <p className="font-['Nunito_Sans'] text-sm text-gray-600 mb-2">1 Subject</p>
                  <p className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-black">$39 <span className="text-sm md:text-base font-normal text-gray-600">AUD/month</span></p>
                </div>
                <div>
                  <p className="font-['Nunito_Sans'] text-sm text-gray-600 mb-2">2 Subjects</p>
                  <p className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-black">$69 <span className="text-sm md:text-base font-normal text-gray-600">AUD/month</span></p>
                </div>
              </div>

              <div className="bg-[#05ac8f] text-white rounded-xl p-4 md:p-6 text-center mb-6">
                <p className="font-['Nunito_Sans'] font-bold text-lg md:text-2xl">4</p>
                <p className="font-['Nunito_Sans'] text-sm">Sessions per Month per Subject</p>
              </div>

              <div className="flex gap-3 justify-center">
                <Link href="/contact">
                  <Button className="h-10 md:h-11 px-6 md:px-8 bg-[#ff9e10] hover:bg-[#ff9e10]/90 rounded-full font-['Nunito_Sans'] font-bold text-white text-sm">
                    Book a Demo Class
                  </Button>
                </Link>
                <Link href="/signup">
                  <Button className="h-10 md:h-11 px-6 md:px-8 bg-[#05ac8f] hover:bg-[#05ac8f]/90 rounded-full font-['Nunito_Sans'] font-bold text-white text-sm">
                    Join
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        )}

        {selectedOffering === "self-learning" && (
          <div className="bg-[#22a3d2] text-white rounded-2xl p-6 md:p-8 relative">
            <h3 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl mb-6 md:mb-8">
              Self Learning
            </h3>

            <div className="flex flex-col md:flex-row gap-6 md:gap-0 md:items-start">
              {/* Left Section - Standard Plans */}
              <div className="flex-1">
                <div className="grid grid-cols-2 gap-6 md:gap-8">
                  {/* 1 Subject */}
                  <div>
                    <p className="font-['Nunito_Sans'] text-xs md:text-sm font-bold mb-2">
                      1 Subject Maths/ English
                    </p>
                    <p className="font-['Nunito_Sans'] font-bold text-xl md:text-2xl mb-1">$13.99</p>
                    <p className="font-['Nunito_Sans'] text-xs md:text-sm mb-3">AUD/month</p>
                    <p className="font-['Nunito_Sans'] font-bold text-xl md:text-2xl mb-1">$139</p>
                    <p className="font-['Nunito_Sans'] text-xs md:text-sm">AUD/year</p>
                  </div>

                  {/* Both Subjects */}
                  <div>
                    <p className="font-['Nunito_Sans'] text-xs md:text-sm font-bold mb-2">
                      Both Maths and English
                    </p>
                    <p className="font-['Nunito_Sans'] font-bold text-xl md:text-2xl mb-1">$21.99</p>
                    <p className="font-['Nunito_Sans'] text-xs md:text-sm mb-3">AUD/month</p>
                    <p className="font-['Nunito_Sans'] font-bold text-xl md:text-2xl mb-1">$219</p>
                    <p className="font-['Nunito_Sans'] text-xs md:text-sm">AUD/year</p>
                  </div>
                </div>
              </div>

              {/* Divider + Vertical Label + White Box */}
              <div className="hidden md:flex items-start md:ml-2 md:mr-0 gap-3">
                {/* Divider Line */}
                <div className="w-1 bg-white opacity-60 h-44"></div>

                {/* Vertical Label */}
                <div className="flex items-start pt-4">
                  <div className="bg-[#0d3d52] px-1 py-16" style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)' }}>
                    <p className="font-['Nunito_Sans'] font-bold text-xs whitespace-nowrap tracking-tight">FAMILY PLAN (UP TO 2 KIDS)</p>
                  </div>
                </div>

                {/* White Box */}
                <div className="bg-white text-black rounded-2xl p-5 md:p-6 md:w-64">
                  <div className="grid grid-cols-2 gap-4">
                    {/* 1 Subject Family */}
                    <div>
                      <p className="font-['Nunito_Sans'] text-xs font-bold text-[#22a3d2] mb-2">
                        1 Subject Maths/ English
                      </p>
                      <p className="font-['Nunito_Sans'] font-bold text-xl text-black mb-1">$19.99</p>
                      <p className="font-['Nunito_Sans'] text-xs font-bold text-gray-800 mb-2">AUD/month</p>
                      <p className="font-['Nunito_Sans'] font-bold text-xl text-black mb-1">$199</p>
                      <p className="font-['Nunito_Sans'] text-xs font-bold text-gray-800">AUD/year</p>
                    </div>

                    {/* Both Subjects Family */}
                    <div>
                      <p className="font-['Nunito_Sans'] text-xs font-bold text-[#22a3d2] mb-2">
                        Both Maths and English
                      </p>
                      <p className="font-['Nunito_Sans'] font-bold text-xl text-black mb-1">$29.99</p>
                      <p className="font-['Nunito_Sans'] text-xs font-bold text-gray-800 mb-2">AUD/month</p>
                      <p className="font-['Nunito_Sans'] font-bold text-xl text-black mb-1">$299</p>
                      <p className="font-['Nunito_Sans'] text-xs font-bold text-gray-800">AUD/year</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Mobile Family Plan */}
              <div className="md:hidden w-full">
                <p className="font-['Nunito_Sans'] font-bold text-sm text-center mb-3">FAMILY PLAN (UP TO 2 KIDS)</p>
                <div className="bg-white text-black rounded-2xl p-4">
                  <div className="grid grid-cols-2 gap-4">
                    {/* 1 Subject Family */}
                    <div>
                      <p className="font-['Nunito_Sans'] text-xs font-bold text-[#22a3d2] mb-2">
                        1 Subject Maths/ English
                      </p>
                      <p className="font-['Nunito_Sans'] font-bold text-lg text-black mb-1">$19.99</p>
                      <p className="font-['Nunito_Sans'] text-xs font-bold text-gray-800 mb-2">AUD/month</p>
                      <p className="font-['Nunito_Sans'] font-bold text-lg text-black mb-1">$199</p>
                      <p className="font-['Nunito_Sans'] text-xs font-bold text-gray-800">AUD/year</p>
                    </div>

                    {/* Both Subjects Family */}
                    <div>
                      <p className="font-['Nunito_Sans'] text-xs font-bold text-[#22a3d2] mb-2">
                        Both Maths and English
                      </p>
                      <p className="font-['Nunito_Sans'] font-bold text-lg text-black mb-1">$29.99</p>
                      <p className="font-['Nunito_Sans'] text-xs font-bold text-gray-800 mb-2">AUD/month</p>
                      <p className="font-['Nunito_Sans'] font-bold text-lg text-black mb-1">$299</p>
                      <p className="font-['Nunito_Sans'] text-xs font-bold text-gray-800">AUD/year</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex gap-3 md:gap-4 justify-center flex-wrap mt-6 md:mt-8">
              <Link href="/contact">
                <Button className="h-10 md:h-11 px-6 md:px-8 bg-[#ff9e10] hover:bg-[#ff9e10]/90 rounded-full font-['Nunito_Sans'] font-bold text-white text-sm">
                  Book a Demo Class
                </Button>
              </Link>
              <Link href="/signup">
                <Button className="h-10 md:h-11 px-6 md:px-8 bg-white hover:bg-gray-100 text-[#22a3d2] rounded-full font-['Nunito_Sans'] font-bold text-sm">
                  Join
                </Button>
              </Link>
            </div>
          </div>
        )}

        {selectedOffering === "co-curricular" && (
          <div className="border-4 border-[#ff9e10] rounded-3xl p-6 md:p-10 bg-white">
            <h3 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#ff9e10] mb-8 text-center">
              Co-Curricular
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 mb-8">
              {/* Piano */}
              <div className="flex flex-col items-center">
                <p className="font-['Nunito_Sans'] text-base md:text-lg text-[#070709] mb-4">Piano</p>
                <p className="font-['Nunito_Sans'] font-bold text-3xl md:text-4xl text-black mb-6">$60 <span className="text-sm md:text-base font-normal text-gray-600">AUD/month</span></p>
                
                <div className="bg-[#ff9e10] text-white rounded-xl px-6 py-4 text-center mb-6 w-full md:w-auto">
                  <p className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl">4</p>
                  <p className="font-['Nunito_Sans'] text-sm">Sessions per Month per Subject</p>
                </div>
              </div>

              {/* Guitar */}
              <div className="flex flex-col items-center">
                <p className="font-['Nunito_Sans'] text-base md:text-lg text-[#070709] mb-4">Guitar</p>
                <p className="font-['Nunito_Sans'] font-bold text-3xl md:text-4xl text-black mb-6">$60 <span className="text-sm md:text-base font-normal text-gray-600">AUD/month</span></p>
                
                <div className="bg-[#ff9e10] text-white rounded-xl px-6 py-4 text-center mb-6 w-full md:w-auto">
                  <p className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl">4</p>
                  <p className="font-['Nunito_Sans'] text-sm">Sessions per Month per Subject</p>
                </div>
              </div>
            </div>

            <div className="flex gap-3 md:gap-4 justify-center flex-wrap">
              <Link href="/contact">
                <Button className="h-10 md:h-11 px-6 md:px-8 bg-[#22a3d2] hover:bg-[#22a3d2]/90 rounded-full font-['Nunito_Sans'] font-bold text-white text-sm">
                  Book a Demo Class
                </Button>
              </Link>
              <Link href="/signup">
                <Button className="h-10 md:h-11 px-6 md:px-8 bg-[#ff9e10] hover:bg-[#ff9e10]/90 rounded-full font-['Nunito_Sans'] font-bold text-white text-sm">
                  Join
                </Button>
              </Link>
            </div>
          </div>
        )}

        {selectedOffering === "naplan" && (
          <div className="border-4 border-[#0f2a47] rounded-3xl p-6 md:p-10 bg-white">
            <h3 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#0f2a47] mb-8 text-center">
              NAPLAN Bootcamp
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 mb-8">
              {/* Live Coaching and Material */}
              <div className="flex flex-col items-center">
                <p className="font-['Nunito_Sans'] text-base md:text-lg text-[#070709] mb-6">Live Coaching and Material</p>
                <p className="font-['Nunito_Sans'] font-bold text-4xl md:text-5xl text-black">$190 <span className="text-sm md:text-base font-normal text-gray-600">AUD</span></p>
              </div>

              {/* Self Learning Material */}
              <div className="flex flex-col items-center">
                <p className="font-['Nunito_Sans'] text-base md:text-lg text-[#070709] mb-6">Self Learning Material</p>
                <p className="font-['Nunito_Sans'] font-bold text-4xl md:text-5xl text-black">$29.90 <span className="text-sm md:text-base font-normal text-gray-600">AUD</span></p>
              </div>
            </div>

            <div className="flex gap-3 md:gap-4 justify-center flex-wrap">
              <Link href="/contact">
                <Button className="h-10 md:h-11 px-6 md:px-8 bg-[#ff9e10] hover:bg-[#ff9e10]/90 rounded-full font-['Nunito_Sans'] font-bold text-white text-sm">
                  Book a Demo Class
                </Button>
              </Link>
              <Link href="/signup">
                <Button className="h-10 md:h-11 px-6 md:px-8 bg-[#0f2a47] hover:bg-[#0f2a47]/90 rounded-full font-['Nunito_Sans'] font-bold text-white text-sm">
                  Join
                </Button>
              </Link>
            </div>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
};
