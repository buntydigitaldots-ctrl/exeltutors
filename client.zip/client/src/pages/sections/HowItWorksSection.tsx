import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const steps = [
  {
    icon: "/figmaAssets/vector-7.svg",
    title: "Assess",
    description:
      "Upload your child's recent assessment scores—or take a free assessment with us to understand their current level.",
  },
  {
    icon: "/figmaAssets/vector-11.svg",
    title: "Plan",
    description:
      "We create a customised learning plan tailored to your child's needs and curriculum.",
  },
  {
    icon: "/figmaAssets/vector-6.svg",
    title: "Experience",
    description:
      "Start with a free trial class to see how engaging and effective online learning can be.",
  },
  {
    icon: "/figmaAssets/vector-5.svg",
    title: "Learn & Grow",
    description:
      "Select a plan, set your schedule, and watch your child's skills and confidence grow.",
  },
];

export const HowItWorksSection = (): JSX.Element => {
  return (
    <section className="relative w-full py-8 md:py-14 px-4 md:px-[100px]">
      <img
        className="absolute inset-0 w-full h-full object-cover -z-10"
        alt="Background"
        src="/figmaAssets/vector-1-1.svg"
      />

      <div className="relative max-w-[1530px] mx-auto">
        <h2 className="font-['Nunito_Sans'] font-extrabold text-[#070709] text-2xl md:text-3xl lg:text-[40px] text-center tracking-[0] leading-normal mb-8 md:mb-16">
          How It Works
        </h2>

        <Card className="bg-white rounded-[10px] shadow-sm mb-8">
          <CardContent className="p-6 md:p-10">
            <div className="flex flex-col md:flex-row items-start justify-between gap-6 md:gap-10">
              {steps.flatMap((step, index) => {
                const elements = [
                  <div key={`step-${index}`} className="flex flex-col gap-5 flex-1">
                    <img
                      className="w-10 md:w-[59px] h-10 md:h-[59px] object-contain"
                      alt={step.title}
                      src={step.icon}
                    />

                    <h3 className="font-['Nunito_Sans'] font-bold text-[#0f2a47] text-lg md:text-2xl lg:text-3xl tracking-[0] leading-[36px]">
                      {step.title}
                    </h3>

                    <p className="font-['Nunito_Sans'] font-normal text-[#070709] text-sm md:text-base lg:text-xl tracking-[0] leading-[30px]">
                      {step.description}
                    </p>
                  </div>
                ];
                
                if (index < steps.length - 1) {
                  elements.push(
                    <img
                      key={`arrow-${index}`}
                      className="hidden md:block w-6 md:w-8 h-3 md:h-4 mt-8 md:mt-[89px] flex-shrink-0"
                      alt="Arrow"
                      src="/figmaAssets/vector-3.svg"
                    />
                  );
                }
                
                return elements;
              })}
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-center">
          <Button className="bg-[#ff9e10] hover:bg-[#ff9e10]/90 rounded-full h-[60px] px-10 font-['Nunito_Sans'] font-bold text-white text-xl tracking-[0] leading-[22px]">
            Take your assessment test
            <img
              className="w-[22px] h-[15px] ml-2"
              alt="Arrow"
              src="/figmaAssets/arrow-1.svg"
            />
          </Button>
        </div>
      </div>
    </section>
  );
};
