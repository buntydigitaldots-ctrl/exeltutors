import React from "react";
import { Card, CardContent } from "@/components/ui/card";

const testimonials = [
  {
    name: "Priya S.",
    text: "Tutorexel has been a wonderful experience for my son. The teachers are professional, and he looks forward to every class!",
    avatar: "/figmaAssets/mask-group.png",
  },
  {
    name: "Rohit K.",
    text: "We love the flexibility and the personalised approach. Highly recommended",
    avatar: "/figmaAssets/mask-group-1.png",
  },
];

export const TestimonialsSection = (): JSX.Element => {
  return (
    <section className="w-full py-8 md:py-16 px-4 md:px-[100px]">
      <div className="max-w-[1530px] mx-auto">
        <h2 className="font-['Nunito_Sans'] font-extrabold text-[#070709] text-2xl md:text-3xl lg:text-[40px] text-center tracking-[0] leading-normal mb-8 md:mb-20">
          What parents and students are saying
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-12 max-w-[1530px] mx-auto">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="relative w-full max-w-[739px] mx-auto">
              <Card className="relative w-full h-[399px] bg-transparent border-0 shadow-none">
                <CardContent className="relative w-full h-full p-0">
                  <img
                    className="absolute top-0 left-0 w-full h-full object-cover"
                    alt="Testimonial Background"
                    src="/figmaAssets/vector-4.svg"
                  />

                  <div className="absolute top-[63px] left-[60px] flex gap-2">
                    {[...Array(5)].map((_, starIndex) => (
                      <img
                        key={starIndex}
                        className="w-[22px] h-[21px]"
                        alt="Star"
                        src="/figmaAssets/star-1.svg"
                      />
                    ))}
                  </div>

                  <p className="absolute top-[106px] left-[60px] w-[619px] font-['Nunito_Sans'] font-normal text-white text-3xl tracking-[0] leading-[45px]">
                    {testimonial.text}
                  </p>

                  <img
                    className="absolute top-[49px] right-[60px] w-[46px] h-[37px]"
                    alt="Quote"
                    src="/figmaAssets/-.svg"
                  />
                </CardContent>
              </Card>

              <div className="absolute top-[345px] left-1/2 -translate-x-1/2 flex items-center gap-5">
                <div className="relative w-[103px] h-[103px]">
                  <div className="absolute inset-0 rounded-full border-2 border-dashed border-[#070709]" />
                  <div className="absolute top-[9px] left-[9px] w-[85px] h-[85px] bg-[#ff9e10] rounded-full" />
                  <img
                    className="absolute top-[9px] left-[9px] w-[85px] h-[85px] rounded-full object-cover"
                    alt={testimonial.name}
                    src={testimonial.avatar}
                  />
                </div>

                <div className="font-['Nunito_Sans'] font-bold text-[#070709] text-3xl tracking-[0] leading-[45px] whitespace-nowrap">
                  {testimonial.name}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
