import { ArrowRightIcon } from "lucide-react";
import React from "react";
import { Button } from "@/components/ui/button";

export const CTASection = (): JSX.Element => {
  return (
    <section className="w-full px-[100px] py-[60px]">
      <div className="bg-[#ff9e10] rounded-[20px] relative overflow-hidden">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-8 p-8 lg:p-16">
          <div className="flex flex-col gap-6 max-w-[760px] z-10">
            <h2 className="font-['Nunito_Sans'] font-black text-white text-[40px] leading-normal">
              Ready to Help Your Child Succeed?
            </h2>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                variant="secondary"
                className="h-[60px] bg-white hover:bg-white/90 rounded-full px-10 text-[#070709] text-xl font-['Nunito_Sans'] font-normal whitespace-nowrap"
              >
                Book Your Free Trial Class
                <ArrowRightIcon className="ml-2 w-5 h-4" />
              </Button>

              <Button className="h-[60px] bg-[#22a3d2] hover:bg-[#22a3d2]/90 rounded-full px-10 text-white text-xl font-['Nunito_Sans'] font-bold whitespace-nowrap">
                Contact Us to Learn More
                <ArrowRightIcon className="ml-2 w-5 h-4" />
              </Button>
            </div>
          </div>

          <div className="relative lg:absolute lg:right-0 lg:top-0 w-full lg:w-[678px] h-[332px] flex-shrink-0">
            <img
              className="w-full h-full object-cover"
              alt="Students learning together"
              src="/figmaAssets/asdfa-1.png"
            />
          </div>
        </div>
      </div>
    </section>
  );
};
