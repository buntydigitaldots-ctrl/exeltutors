import React from "react";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";

const yearCards = [
  {
    year: "Year 2",
    description:
      "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum",
  },
  {
    year: "Year 3",
    description:
      "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum",
  },
  {
    year: "Year 4",
    description:
      "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum",
  },
  {
    year: "Year 5",
    description:
      "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum",
  },
  {
    year: "Year 6",
    description:
      "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum",
  },
  {
    year: "Year 7",
    description:
      "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum",
  },
  {
    year: "Year 8",
    description:
      "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum",
  },
  {
    year: "Year 9",
    description:
      "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum",
  },
  {
    year: "Year 10",
    description:
      "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum",
  },
];

export const CourseCurriculumSection = (): JSX.Element => {
  return (
    <section className="relative w-full bg-[#f7f6ee] py-8 md:py-[70px] px-4 md:px-[100px]">
      <img
        className="absolute inset-0 w-full h-full object-cover -z-10"
        alt="Background"
        src="/figmaAssets/mask-group-2.png"
      />

      <div className="relative max-w-[1530px] mx-auto">
        <h2 className="font-['Nunito_Sans'] font-extrabold text-black text-2xl md:text-3xl lg:text-[40px] text-center tracking-[0] leading-normal mb-6 md:mb-10">
          Course Curriculum
        </h2>

        <p className="font-['Nunito_Sans'] font-extrabold text-black text-xl md:text-2xl lg:text-[40px] text-center tracking-[0] leading-normal mb-8 md:mb-16">
          Click on the subject to know our 40 Sessions syllabus
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-x-12 md:gap-y-12 mb-8 md:mb-12">
          {yearCards.map((card, index) => (
            <Link key={index} href={`/curriculum/${card.year.toLowerCase().replace(" ", "-")}`}>
              <Card className="bg-white rounded-[10px] border-0 shadow-none cursor-pointer hover:shadow-lg transition-shadow">
                <CardContent className="p-4 md:p-8 lg:p-10 flex flex-col items-center w-full">
                  <h3 className="font-['Nunito_Sans'] font-bold text-[#070709] text-lg md:text-xl lg:text-2xl text-center tracking-[0] leading-normal mb-2 md:mb-3">
                    {card.year}
                  </h3>

                  <p className="font-['Nunito_Sans'] font-normal text-[#070709] text-xs md:text-sm lg:text-base text-center tracking-[0] leading-relaxed mb-4 md:mb-6 px-2">
                    {card.description}
                  </p>

                  <div className="flex gap-2 md:gap-3 flex-wrap justify-center">
                    <Badge className="bg-[#ff9e10] hover:bg-[#ff9e10]/90 text-white font-['Nunito_Sans'] font-bold text-xs md:text-sm text-center tracking-[0] leading-[15.4px] rounded-full px-3 md:px-4 py-2 md:py-3 h-8 md:h-10">
                      English
                    </Badge>
                    <Badge className="bg-[#ff9e10] hover:bg-[#ff9e10]/90 text-white font-['Nunito_Sans'] font-bold text-xs md:text-sm text-center tracking-[0] leading-[15.4px] rounded-full px-3 md:px-4 py-2 md:py-3 h-8 md:h-10">
                      Maths
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        <div className="flex justify-center px-4">
          <Card className="bg-[#22a3d2] rounded-[10px] border-0 shadow-none cursor-pointer hover:shadow-lg transition-shadow w-full max-w-xs md:max-w-md lg:max-w-[480px]">
            <CardContent className="p-4 md:p-8 lg:p-10 flex flex-col items-center">
              <h3 className="font-['Nunito_Sans'] font-bold text-white text-xl md:text-2xl lg:text-3xl text-center tracking-[0] leading-normal mb-2 md:mb-3">
                NAPLAN
              </h3>

              <p className="font-['Nunito_Sans'] font-normal text-white text-xs md:text-base lg:text-lg text-center tracking-[0] leading-relaxed mb-4 md:mb-6 px-2">
                Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum
              </p>

              <div className="flex gap-2 md:gap-3 flex-wrap justify-center">
                <Badge className="bg-white hover:bg-white/90 text-black font-['Nunito_Sans'] font-bold text-xs md:text-sm text-center tracking-[0] leading-[15.4px] rounded-full px-3 md:px-4 py-2 md:py-3 h-8 md:h-10">
                  English
                </Badge>
                <Badge className="bg-white hover:bg-white/90 text-black font-['Nunito_Sans'] font-bold text-xs md:text-sm text-center tracking-[0] leading-[15.4px] rounded-full px-3 md:px-4 py-2 md:py-3 h-8 md:h-10">
                  Maths
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};
