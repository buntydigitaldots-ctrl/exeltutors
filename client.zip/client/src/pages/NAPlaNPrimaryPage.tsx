import React from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { CheckCircle } from "lucide-react";

export const NAPlaNPrimaryPage = (): JSX.Element => {
  return (
    <div className="bg-white w-full min-h-screen">
      <Header showFreeTrial />

      {/* Hero Section */}
      <div className="w-full bg-gradient-to-r from-[#d4f1f4] to-[#fff9e6] py-8 md:py-12">
        <div className="px-4 md:px-[100px]">
          <h1 className="font-['Nunito_Sans'] font-bold text-3xl md:text-4xl text-[#070709] mb-2">
            Primary NAPLAN Tutoring for Years 3 & 5
          </h1>
          <p className="font-['Nunito_Sans'] text-sm md:text-base text-[#070709]">
            Support in English and Maths to help younger learners approach NAPLAN with confidence.
          </p>
        </div>
      </div>

      <div className="w-full px-4 md:px-[100px] py-8 md:py-16">
        {/* What We Cover */}
        <div className="mb-12 md:mb-16">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] mb-10 text-center">
            What We Cover
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { title: "Reading", desc: "Understand different text types, fluency, vocabulary, answer comprehension" },
              { title: "Writing", desc: "Plan and write effective short narratives and persuasive forms" },
              { title: "Language Conventions", desc: "Practice spelling, punctuation, grammar, 3 and Year 5 levels" },
              { title: "Numeracy", desc: "Strengthen number operations, measurement, shapes and data interpretation" }
            ].map((item, idx) => (
              <div key={idx} className="text-center">
                <div className="text-3xl mb-2">💡</div>
                <h3 className="font-['Nunito_Sans'] font-bold text-base text-[#070709] mb-1">{item.title}</h3>
                <p className="font-['Nunito_Sans'] text-xs text-[#070709]">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* How We Help Students Succeed */}
        <div className="mb-12 md:mb-16 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] mb-6">
              How We Help Students Succeed
            </h2>
            
            <div className="space-y-3">
              <div className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-[#22a3d2] flex-shrink-0 mt-0.5" />
                <p className="font-['Nunito_Sans'] text-base text-[#070709]">Gentle introduction to the test format as children know what to expect</p>
              </div>
              <div className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-[#22a3d2] flex-shrink-0 mt-0.5" />
                <p className="font-['Nunito_Sans'] text-base text-[#070709]">Use exam practice sets to build familiarity without pressure</p>
              </div>
              <div className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-[#22a3d2] flex-shrink-0 mt-0.5" />
                <p className="font-['Nunito_Sans'] text-base text-[#070709]">Step-by-step revision guidance with feedback.</p>
              </div>
              <div className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-[#22a3d2] flex-shrink-0 mt-0.5" />
                <p className="font-['Nunito_Sans'] text-base text-[#070709]">Mock practices tests under timed conditions to build confidence.</p>
              </div>
              <div className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-[#22a3d2] flex-shrink-0 mt-0.5" />
                <p className="font-['Nunito_Sans'] text-base text-[#070709]">Regular updates to parents on progress and areas for improvement.</p>
              </div>
            </div>
          </div>
          
          <div className="bg-[#f5f5f5] h-[300px] rounded-xl flex items-center justify-center">
            <img src="/figmaAssets/placeholder-img.png" alt="Students" className="w-full h-full object-cover rounded-xl" />
          </div>
        </div>

        {/* When to Start Preparation */}
        <div className="mb-12 md:mb-16 bg-[#f0f8fb] p-8 rounded-xl">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-[#070709] mb-4">
            When to Start
          </h2>
          
          <ul className="space-y-2">
            <li className="font-['Nunito_Sans'] text-base text-[#070709] flex gap-2">
              <span className="text-[#ff9e10]">•</span>
              <span>For Year 3 students, light preparation can begin in Year 2, with focused work in Term 1 of Year 3.</span>
            </li>
            <li className="font-['Nunito_Sans'] text-base text-[#070709] flex gap-2">
              <span className="text-[#ff9e10]">•</span>
              <span>For Year 5 students, start in Year 4 Term 4 or early in Year 5 for best results.</span>
            </li>
          </ul>
        </div>

        {/* Why Parents Choose Tutorexel */}
        <div className="mb-12 md:mb-16 bg-[#ff9e10] py-12 px-6 md:px-12 rounded-2xl">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl md:text-3xl text-white text-center mb-10">
            Why Parents Choose Tutorexel
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { title: "Personalised attention through one-to-one or group classes", icon: "👥" },
              { title: "Qualified tutors who understand the Australian Curriculum", icon: "🎓" },
              { title: "A supportive, encouraging environment that helps children feel capable, not pressured", icon: "💪" }
            ].map((item, idx) => (
              <div key={idx} className="bg-white rounded-xl p-6 text-center">
                <p className="text-3xl mb-2">{item.icon}</p>
                <p className="font-['Nunito_Sans'] font-bold text-sm text-[#070709]">{item.title}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-[#22a3d2] text-white py-12 px-8 rounded-2xl text-center">
          <h2 className="font-['Nunito_Sans'] font-bold text-2xl mb-6">
            Experience the change today.
          </h2>
          <div className="flex gap-3 justify-center flex-wrap">
            <Link href="/contact">
              <Button className="bg-white text-[#22a3d2] hover:bg-gray-100 font-bold rounded-full">
                Book Your Free Trial Class
              </Button>
            </Link>
            <Link href="/signup">
              <Button className="bg-[#ff9e10] hover:bg-[#e68900] text-white font-bold rounded-full">
                Enroll on a tutoring plan
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};
