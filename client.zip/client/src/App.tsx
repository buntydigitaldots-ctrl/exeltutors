import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

import { Homepage } from "@/pages/Homepage";
import { CurriculumPage } from "@/pages/CurriculumPage";
import { PracticeTestPage } from "@/pages/PracticeTestPage";
import { PricingPage } from "@/pages/PricingPage";
import { AboutPage } from "@/pages/AboutPage";
import { BlogsPage } from "@/pages/BlogsPage";
import { ContactPage } from "@/pages/ContactPage";
import { FAQsPage } from "@/pages/FAQsPage";
import { ICASPage } from "@/pages/ICASPage";
import { ICASPrimaryPage } from "@/pages/ICASPrimaryPage";
import { ICASSecondaryPage } from "@/pages/ICASSecondaryPage";
import { NAPlaNPage } from "@/pages/NAPlaNPage";
import { NAPlaNPrimaryPage } from "@/pages/NAPlaNPrimaryPage";
import { NAPlaNSecondaryPage } from "@/pages/NAPlaNSecondaryPage";
import { PianoPage } from "@/pages/PianoPage";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Homepage} />
      <Route path="/about" component={AboutPage} />
      <Route path="/pricing" component={PricingPage} />
      <Route path="/blogs" component={BlogsPage} />
      <Route path="/contact" component={ContactPage} />
      <Route path="/faqs" component={FAQsPage} />
      <Route path="/icas" component={ICASPage} />
      <Route path="/icas/primary" component={ICASPrimaryPage} />
      <Route path="/icas/secondary" component={ICASSecondaryPage} />
      <Route path="/naplan" component={NAPlaNPage} />
      <Route path="/naplan/primary" component={NAPlaNPrimaryPage} />
      <Route path="/naplan/secondary" component={NAPlaNSecondaryPage} />
      <Route path="/piano" component={PianoPage} />
      <Route path="/curriculum/:year" component={CurriculumPage} />
      <Route path="/curriculum/:year/:topic" component={PracticeTestPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
